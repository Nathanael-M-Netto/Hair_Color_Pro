# Hair Color Pro v2 — Plano de Execução (Bulletproof)

> **Como usar este documento:** este plano foi escrito para ser **terceirizável**. Cada fase tem (1) comandos exatos a executar, (2) arquivos exatos a criar, (3) snippets de referência e (4) **critérios de aceite mensuráveis**. Se algo neste plano estiver ambíguo, é bug do plano — abra issue antes de improvisar.

---

## 0. Sumário Executivo (TLDR)

Reescrita completa do app **Hair Color Pro** abandonando Flutter. Nova stack: **Next.js 15 (App Router) + TypeScript + Tailwind v4 + shadcn/ui + reactbits.dev + Capacitor 6**, com **identidade visual glassmorphism** e **IA de visão computacional** para diagnóstico automático de tom capilar e cobertura de brancos.

- **Frontend**: Next.js 15 (App Router, Server Components) + TS estrito.
- **Estilo**: Tailwind v4 + shadcn/ui (tema customizado glass) + efeitos reactbits.
- **Mobile**: app nativo iOS/Android via **Capacitor 6** (empacota o build web em projetos Xcode/Android Studio reais). PWA instalável é bônus, não substituto.
- **IA**: modelo de Computer Vision hospedado (Replicate ou HF Inference Endpoints) + fallback heurístico de **resiliência** (rede ruim / cold start) — **não** é modo offline.
- **Backend leve**: Route Handlers do próprio Next.js + Supabase (Auth + Postgres + Storage). Migração do Firebase legado documentada na Fase 2.
- **Domínio**: serviço `ColorimetriaService.ts` reescrito com regras testáveis, volumagem de OX, proporções e cobertura de brancos.

**Conectividade**: o app **requer internet** para login e análise de IA. O fallback heurístico cobre apenas falhas pontuais de rede ou de cold start do provedor de IA — não é "modo avião".

**Meta de qualidade visual:** o app deve passar no "teste do print" — qualquer screenshot postada em redes sociais deve parecer um app premium pago.

---

## 1. Decisão de Stack — Por que Next.js + Capacitor (e não React Native)

O plano anterior previa **React Native + NativeWind**. Essa decisão **foi revertida** pelos motivos abaixo. A justificativa completa está em `ARQUITETURA_JUSTIFICATIVA.md`.

- **shadcn/ui é web-only.** Depende de DOM, Radix, Framer Motion. Em RN seria reimplementação total.
- **reactbits.dev é web-only.** Os efeitos (Aurora, Beams, Shiny Text, Magic Bento, Splash Cursor, etc.) usam Canvas/WebGL/SVG/CSS `backdrop-filter`. Não rodam em RN sem reescrita.
- **`backdrop-filter` (glass real)** é trivial no web e dolorido no RN (`expo-blur` tem limitações sérias de performance e composição).
- **Distribuição em loja segue garantida** via Capacitor 6 (gera projetos Xcode/Android Studio nativos a partir do build web).
- **Câmera** funciona via `getUserMedia` no web e `@capacitor/camera` no nativo — mesma camada de UI, dois plugins.
- **Offline não é requisito** do produto (login obrigatório + IA dependem de rede), o que remove o último argumento histórico a favor de RN puro. Tornaria a discussão "RN pelo storage local" sem propósito real aqui.

**Resultado:** ganhamos shadcn + reactbits **de graça**, mantemos publicação nas lojas, e o ciclo dev (`pnpm dev` → ver no navegador) fica brutalmente mais rápido.

---

## 2. Stack Tecnológica Detalhada (com versões alvo)

> Versões abaixo são o **piso mínimo**. Sempre instale a versão estável mais recente no início do projeto e congele no `package.json` com `pnpm`.

### 2.1 Core
| Pacote | Versão alvo | Função |
|---|---|---|
| `next` | `^15.0.0` | Framework (App Router, RSC, Route Handlers) |
| `react` / `react-dom` | `^19.0.0` | UI |
| `typescript` | `^5.6.0` | Type safety |
| `tailwindcss` | `^4.0.0` | Estilo utilitário |
| `@tailwindcss/postcss` | `^4.0.0` | Plugin PostCSS |

### 2.2 UI / Componentes
| Pacote | Função |
|---|---|
| `shadcn` (CLI) | `npx shadcn@latest init` — gera componentes locais |
| `lucide-react` | Ícones (padrão do shadcn) |
| `class-variance-authority`, `clsx`, `tailwind-merge` | Helpers do shadcn |
| `@radix-ui/react-*` | Primitivos sem estilo (instalados sob demanda pelo shadcn) |
| `framer-motion` ou `motion` | Animações dos efeitos reactbits |
| `tailwindcss-animate` | Animações utilitárias |
| `next-themes` | Toggle dark/light |
| `sonner` | Toasts (shadcn pattern) |

### 2.3 reactbits.dev — efeitos visuais
Os componentes do reactbits são **copy-paste** (não é uma lib NPM tradicional). Cada um vira um arquivo em `src/components/bits/<NomeDoEfeito>.tsx`. Lista exata na **Seção 4**.

### 2.4 Estado & dados
| Pacote | Função |
|---|---|
| `zustand` | Estado global leve (sessão de análise atual) |
| `@tanstack/react-query` | Cache de inferências, retries, loading/error states |
| `zod` | Validação de schemas (input do form, resposta da IA, env vars) |
| `react-hook-form` + `@hookform/resolvers` | Forms |

### 2.5 Backend & infra
| Pacote | Função |
|---|---|
| `@supabase/supabase-js` | Auth + Postgres + Storage de fotos |
| `replicate` **ou** `@huggingface/inference` | SDK do provedor de IA escolhido |
| `sharp` | Pré-processamento de imagem server-side (crop, resize, normalize) |

### 2.6 Mobile shell
| Pacote | Função |
|---|---|
| `@capacitor/core`, `@capacitor/cli` | Capacitor 6 |
| `@capacitor/camera` | Câmera nativa iOS/Android |
| `@capacitor/preferences` | Storage nativo |
| `@capacitor/haptics` | Feedback tátil |
| `@capacitor/share` | Compartilhar fórmula |

### 2.7 Dev / qualidade
| Pacote | Função |
|---|---|
| `eslint`, `eslint-config-next` | Lint |
| `prettier`, `prettier-plugin-tailwindcss` | Format |
| `vitest`, `@testing-library/react`, `@testing-library/jest-dom` | Testes unitários e de componente |
| `playwright` | Testes E2E |
| `husky`, `lint-staged` | Git hooks |

---

## 3. Identidade Visual — Glass + shadcn + reactbits

### 3.1 Princípios de design (foco: salão premium, não startup de IA)

A paleta original (violeta/magenta/ciano) foi descartada — referencia genérico de SaaS/IA. O app é uma **ferramenta profissional para cabeleireiros**; a identidade visual precisa comunicar isso: dark mode quente, **cobre como única cor de marca**, tipografia editorial, animações contidas.

**Referências visuais aprovadas:**
- L'Oréal Professionnel (preto + cobre)
- Davines (off-white + neutro quente)
- Linear / Vercel (escuro minimalista com 1 cor de destaque)
- Sézane (luxo discreto, sem floreios)

**Anti-referências:**
- Gradientes arco-íris ("dashboards de IA")
- Neons saturados, ciano "tech"
- Glassmorphism multicolorido tipo macOS Big Sur preview
- Qualquer coisa que pareça "demo de design system"

**Princípios:**
1. **Monocromático com 1 acento.** Tudo é tons de carvão quente. Apenas o cobre se destaca, e mesmo assim com parcimônia (1 elemento por tela, no máximo).
2. **Glass primeiro, sólido depois.** Toda superfície elevada (cards, modais, sheet, navbar) usa `backdrop-blur` + borda sutil + sombra interna.
3. **Contraste preservado.** Texto em `foreground` puro sobre o glass; nunca sobre gradiente direto.
4. **Profundidade em três camadas:** (a) fundo ambiente sutil (Aurora **monocromática cobre**, baixa opacidade), (b) superfícies glass, (c) conteúdo sólido (texto/ícones).
5. **Motion com propósito.** Animações comunicam estado (IA carregando, sucesso, erro). Nenhuma decoração gratuita.
6. **Acessibilidade não é opcional.** Contraste AA mínimo (4.5:1), `prefers-reduced-motion` respeitado em **todo** efeito reactbits.

### 3.2 Design tokens (entrar em `src/app/globals.css`)

> **Decisão registrada (D-001):** paleta cobre sobre carvão quente. Cobre escolhido por (a) referência direta à indústria de coloração capilar, (b) ser cor "quente" não saturada, percebida como premium e não-tech, (c) contrastar bem com glass dark sem brigar visualmente.

```css
@import "tailwindcss";

@theme {
  /* ====== Base — carvão quente (warm charcoal) ====== */
  --color-background: 24 8% 5%;            /* #0E0C0B — quase preto com toque âmbar */
  --color-foreground: 30 12% 96%;          /* #F7F4F1 — off-white levemente quente */
  --color-card: 24 8% 9% / 0.65;           /* superfície glass — translúcida sobre bg */
  --color-card-foreground: 30 12% 96%;
  --color-popover: 24 8% 8% / 0.85;
  --color-popover-foreground: 30 12% 96%;

  /* ====== Marca — cobre único ====== */
  --color-primary: 24 55% 52%;             /* #C8794A — cobre maduro, não estridente */
  --color-primary-foreground: 30 15% 98%;
  --color-primary-muted: 24 35% 35%;       /* cobre rebaixado p/ hover/disabled */

  /* ====== Suporte — escala neutra quente ====== */
  --color-muted: 24 6% 14%;                /* card sólido, inputs */
  --color-muted-foreground: 30 6% 62%;     /* texto secundário */
  --color-secondary: 24 6% 18%;            /* botão secundário sólido */
  --color-secondary-foreground: 30 12% 96%;
  --color-accent: 30 18% 75%;              /* champagne — destaque sutil, NÃO segunda cor de marca */
  --color-accent-foreground: 24 10% 8%;

  /* ====== Border / ring ====== */
  --color-border: 30 10% 100% / 0.06;
  --color-input: 30 10% 100% / 0.08;
  --color-ring: 24 55% 52%;

  /* ====== Estados ====== */
  --color-destructive: 8 65% 52%;          /* vermelho-tijolo, não puro */
  --color-destructive-foreground: 30 15% 98%;
  --color-success: 140 30% 45%;            /* verde dessaturado */
  --color-warning: 35 75% 55%;             /* âmbar — distinto do cobre primário */

  /* ====== Raio ====== */
  --radius-sm: 0.375rem;
  --radius-md: 0.625rem;
  --radius-lg: 0.875rem;
  --radius-xl: 1.25rem;

  /* ====== Glass ====== */
  --glass-blur: 20px;
  --glass-saturation: 140%;                /* MENOR que o padrão flashy — saturação contida */
  --glass-border: rgba(255, 245, 235, 0.07);
  --glass-shadow: 0 12px 40px rgba(0, 0, 0, 0.45);
  --glass-inset: inset 0 1px 0 rgba(255, 245, 235, 0.05);

  /* ====== Fontes ====== */
  --font-sans: 'Geist', ui-sans-serif, system-ui, sans-serif;
  --font-serif: 'Instrument Serif', 'Times New Roman', serif;   /* opcional, p/ números heroicos */
  --font-mono: 'Geist Mono', ui-monospace, monospace;
}

/* Utilitários reutilizáveis */
@layer utilities {
  .glass {
    background: hsl(var(--color-card));
    backdrop-filter: blur(var(--glass-blur)) saturate(var(--glass-saturation));
    -webkit-backdrop-filter: blur(var(--glass-blur)) saturate(var(--glass-saturation));
    border: 1px solid var(--glass-border);
    box-shadow: var(--glass-shadow), var(--glass-inset);
  }
  .glass-strong { /* modais / drawers */
    background: hsl(24 8% 7% / 0.82);
    backdrop-filter: blur(28px) saturate(150%);
    -webkit-backdrop-filter: blur(28px) saturate(150%);
    border: 1px solid var(--glass-border);
  }
  .glass-subtle { /* chips, badges, inputs */
    background: hsl(30 10% 100% / 0.035);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid var(--glass-border);
  }
  /* Fallback para dispositivos sem backdrop-filter */
  html.no-glass .glass,
  html.no-glass .glass-strong,
  html.no-glass .glass-subtle {
    background: hsl(24 8% 11%);
    backdrop-filter: none;
  }
}
```

> **Crítico:** dispositivos antigos podem não suportar `backdrop-filter`. Em `src/lib/feature-detect.ts` faça um `CSS.supports('backdrop-filter','blur(1px)')` e aplique a classe `no-glass` no `<html>` quando falso.

### 3.2.1 Modo claro (futuro, não MVP)
O MVP é **dark-only**. Modo claro fica documentado mas implementação adiada para Fase 9+. Cabeleireiros trabalham em ambientes com iluminação controlada — dark é estratégico.

### 3.3 Componentes shadcn a instalar (lista fechada)

Rodar **um por um** após `init`:

```bash
npx shadcn@latest add button input label form textarea
npx shadcn@latest add card dialog sheet drawer
npx shadcn@latest add tabs accordion separator
npx shadcn@latest add badge avatar progress skeleton
npx shadcn@latest add tooltip popover dropdown-menu
npx shadcn@latest add toast sonner
npx shadcn@latest add slider switch toggle
```

Cada componente deve ser **modificado** para usar a classe `.glass` por padrão na variant principal. Crie variants `solid` e `glass` em `card.tsx`, `dialog.tsx`, `sheet.tsx`, `button.tsx`.

### 3.4 Catálogo de efeitos reactbits.dev — curado para o tom corporativo

> **Decisão registrada (D-002):** dos ~40 efeitos do reactbits.dev, **apenas 8 entram** no MVP. Todos foram filtrados pelo critério "soma elegância sem parecer demo". Efeitos como SplashCursor, MagicBento (com brilho neon) e PixelTransition foram **rejeitados**.

| Efeito | Arquivo destino | Onde usar | Justificativa |
|---|---|---|---|
| **Aurora** (variante monocromática) | `bits/Aurora.tsx` | Layout do `(marketing)` e do `(app)` em baixa opacidade | Profundidade ambiente. **Apenas tons de cobre/carvão**, não os gradientes padrão. |
| **ShinyText** | `bits/ShinyText.tsx` | Logo/headline da landing e CTA principal | Discreto, sugere "polimento", não "tech" |
| **GradientText** | `bits/GradientText.tsx` | Apenas no **número do tom detectado** no resultado | Cobre → champagne, somente 1 elemento por tela |
| **CountUp** | `bits/CountUp.tsx` | "% de brancos", volumagem do OX, tempo de pausa | Comunica precisão numérica |
| **AnimatedList** | `bits/AnimatedList.tsx` | Lista de passos da fórmula | Hierarquia narrativa, sem brilho |
| **BlurText** | `bits/BlurText.tsx` | Revelação do diagnóstico após loading de IA | Liga "processando" → "resultado" |
| **TiltedCard** (sutil, ≤4° de tilt) | `bits/TiltedCard.tsx` | Cards do histórico no dashboard | Tátil, premium |
| **GlareHover** (apenas no botão primário) | `bits/GlareHover.tsx` | CTA "Analisar com IA" | Único efeito de hover do app |

**Efeitos rejeitados e por quê:**
- ❌ **Beams / Light Rays** — visual "matrix", excesso para o contexto salão.
- ❌ **SplashCursor / ClickSpark** — touch-first; em desktop fica brega.
- ❌ **MagicBento (versão neon)** — colorido demais.
- ❌ **PixelTransition** — agressivo, distrai do conteúdo.
- ❌ **ScrambledText** — clichê de "hacker", anti-profissional.
- ❌ **DecryptedText** — idem.
- ❌ **3D Globe / Spheres** — sem relação semântica com o produto.

**Regra de ouro:** **nenhum efeito sem `prefers-reduced-motion`.** Todo arquivo `bits/*.tsx` deve abrir com:

```tsx
'use client';
import { useReducedMotion } from '@/hooks/use-reduced-motion';
export function Aurora({ children }: { children?: React.ReactNode }) {
  const reduced = useReducedMotion();
  if (reduced) return <>{children}</>;
  // ...resto do efeito
}
```

### 3.5 Tipografia

| Uso | Fonte | Razão |
|---|---|---|
| **UI geral** | Geist Sans (peso 400/500) | Neutra, moderna, sem personalidade barulhenta |
| **Heading hero (raro)** | Instrument Serif | Toque editorial, evoca revistas de beleza |
| **Números (tom, %, gramas, ml)** | Geist Mono (peso 500) | Monoespaçado = instrumento de precisão |
| **Botões e labels técnicos** | Geist Sans uppercase tracking-wider | Hierarquia clara |

> **Decisão registrada (D-003):** Geist é o default. Instrument Serif só aparece em 1 elemento por tela (headline hero ou número do tom no resultado), nunca em texto corrido.

### 3.6 Espaçamento e ritmo
- Escala baseada em múltiplos de **4px**: `4, 8, 12, 16, 24, 32, 48, 64, 96`.
- Container principal: `max-w-md` no mobile, `max-w-2xl` no desktop. O app é vertical, mobile-first.
- Raio padrão para superfícies grandes: `rounded-xl` (1rem). Pequenos: `rounded-md`. Pílulas: `rounded-full`.

---

## 4. Módulo de IA — Reconhecimento de Cor com Espectro Restrito

> **Esclarecimento importante**: a heurística local descrita abaixo **não é "modo offline"**. O app exige internet para login e para a chamada principal da IA. A heurística existe apenas como **degradação graciosa** quando a rede está instável ou quando o provedor remoto está em cold start — o usuário não fica preso esperando 10 segundos por uma resposta.

### 4.0 Filosofia: "snap-to-palette" em vez de regressão livre

> **Decisão registrada (D-004):** o módulo de IA **não retorna uma cor RGB livre**. Ele retorna **o índice da entrada mais próxima em uma paleta de referência fechada** (12 tons × 9 reflexos + cabelos ruivos especiais = ~120 entradas). Isso elimina respostas "estranhas" (ex: "altura 6.7", "reflexo violeta-acobreado mediano") e força o sistema a falar a língua da indústria — que é a mesma do `ColorimetriaService`.

**Vantagens objetivas:**
- **Determinismo na saída**: sempre um valor da escala 1-12 + reflexo `.0` a `.8` real, nunca uma interpolação não-existente.
- **Calibração simples**: a paleta de referência é o ground-truth. Ajustar 1 entrada corrige toda uma classe de fotos.
- **Auditável**: para cada inferência, sabemos o ΔE (distância CIEDE2000) entre o pixel médio extraído e a entrada escolhida. Se ΔE > limiar, marcamos como `baixa_confianca`.
- **Custo baixíssimo**: o "modelo" é uma busca k-NN sobre 120 vetores Lab. Roda em < 10ms no client.

### 4.1 Estratégia em 5 etapas

```
┌─────────────────────────────────────────────────────────────┐
│ 1. CAPTURA                                                  │
│    - <input type="file" capture="environment"> (web)        │
│    - @capacitor/camera (nativo)                             │
│    - Overlay circular guia mostrando onde posicionar o      │
│      cabelo (50% da altura da tela)                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. SEGMENTAÇÃO DO CABELO                                    │
│    Estratégia em prioridade:                                │
│    a) MediaPipe Selfie Segmenter (browser, WebGL, gratuito) │
│       → máscara de pessoa, refinada com filtros morfológicos│
│       para isolar topo (cabelo)                             │
│    b) Fallback: usar o ROI do overlay (círculo central)     │
│                                                             │
│    Saída: ImageData só do cabelo, pixels não-cabelo = alpha 0│
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. EXTRAÇÃO DE COR REPRESENTATIVA (client-side, puro JS)    │
│    - Converter todos os pixels válidos para CIE Lab (D65)   │
│    - Cluster k-means com k=3 (cor dominante + 2 secundárias)│
│    - Filtrar clusters com L muito alto (highlights/reflexo  │
│      especular) e muito baixo (sombra profunda)             │
│    - Detectar brancos: pixels com L > 78 e Chroma < 8       │
│      → contar como % do total                               │
│    - Devolver: { lab_dominante, lab_secundaria, pct_brancos │
│                  warm_cast_score }                          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. SNAP À PALETA DE REFERÊNCIA                              │
│    - Calcular ΔE (CIEDE2000) entre lab_dominante e cada     │
│      entrada da paleta (REFERENCE_PALETTE)                  │
│    - Pegar a entrada com menor ΔE                           │
│    - Confiança = 1 - min(ΔE / ΔE_max_tolerado, 1)           │
│      onde ΔE_max_tolerado = 12 (limiar empírico)            │
│    - Se confiança < 0.55: marcar como `revisao_obrigatoria` │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. (OPCIONAL) RE-AVALIAÇÃO REMOTA                           │
│    - Se confiança < 0.7 OU warm_cast severo:                │
│      enviar imagem para Replicate/HF com prompt estruturado │
│    - Modelo retorna outra previsão; comparamos com a local. │
│    - Se divergirem em >2 níveis, mostrar AMBAS ao usuário   │
│      para escolha (não decidir por ele).                    │
│    - Se rede falhar: seguir com a previsão local + aviso.   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. REVISÃO HUMANA OBRIGATÓRIA                               │
│    - Sliders editáveis pré-preenchidos com a previsão       │
│    - Toda correção é persistida → dataset de treino futuro  │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 Paleta de referência (espectro restrito)

Arquivo: `src/lib/colorimetria/reference-palette.ts`

**Estrutura:**
```ts
export interface PaletteEntry {
  /** ID único, ex: "5.0", "6.3", "7.46" */
  id: string;
  /** Altura de tom (1-12) */
  altura: number;
  /** Primeiro reflexo (0-9), `null` se for tom puro natural */
  reflexo_primario: number | null;
  /** Segundo reflexo opcional (cores duplas, ex: 7.46 = cobre + irisado) */
  reflexo_secundario: number | null;
  /** Nome industrial — espelha catálogos L'Oréal/Wella */
  nome: string;
  /** Subtom percebido */
  subtom: 'frio' | 'neutro' | 'quente';
  /** Coordenadas CIE Lab (D65) — ground truth para snap */
  lab: { L: number; a: number; b: number };
  /** Hex de visualização (NÃO usado para cálculo) */
  hex: string;
  /** Categoria para filtragem na UI */
  categoria: 'natural' | 'loiro' | 'ruivo' | 'fantasia';
}

export const REFERENCE_PALETTE: ReadonlyArray<PaletteEntry> = [
  // 12 tons naturais (.0)
  { id: '1.0',  altura: 1,  reflexo_primario: 0, reflexo_secundario: null,
    nome: 'Preto',                  subtom: 'neutro', hex: '#0E0A07',
    lab: { L: 8,  a: 1,  b: 2  }, categoria: 'natural' },
  // ... (lista completa fica em reference-palette.ts — ver Fase 4)
];
```

**Categorias cobertas (espectro restrito explícito):**
1. **Naturais (12 tons × `.0`)**: do preto puro (1.0) ao loiro platinado (12.0).
2. **Loiros frios/quentes (.1 a .3)**: 6.1, 6.2, 6.3, 7.1, 7.2, 7.3, 8.1 ... 10.3.
3. **Ruivos / acobreados (.4, .43, .44, .46, .56, .64)**: 5.4, 6.4, 6.43, 7.4, 7.43, 7.46, 8.4 — cobertura completa da família ruiva.
4. **Mognos / Caobas (.5, .56)**: 4.5, 5.5, 6.5, 6.56.
5. **Vermelhos puros (.6, .66)**: 5.6, 6.6, 7.6.
6. **Marrom/Matte (.7)**: 4.7, 5.7, 6.7 — neutralizador de vermelho residual.
7. **Pérola/Bege (.8, .81)**: 8.8, 9.8, 10.8.

**Fora do escopo do MVP:** cores fantasia puras (rosa, azul, verde). O app sugere a base + descoloração e o usuário aplica fantasia manualmente.

### 4.3 Contrato da API de IA

`POST /api/analyze` recebe `multipart/form-data` com campo `image` (JPEG ≤ 1MB, 512×512 recomendado após pré-processamento).

**Response Schema (Zod, em `src/lib/schemas/analysis.ts`):**

```ts
export const AnalysisResultSchema = z.object({
  /** ID da entrada da paleta de referência (ex: "6.3") */
  paleta_id: z.string().regex(/^\d{1,2}(\.\d{1,2})?$/),
  altura_tom: z.number().int().min(1).max(12),
  reflexo_primario: z.number().int().min(0).max(9).nullable(),
  reflexo_secundario: z.number().int().min(0).max(9).nullable(),
  subtom: z.enum(['frio', 'neutro', 'quente']),
  porcentagem_brancos: z.number().int().min(0).max(100),
  /** 0-1, baseado em ΔE para a paleta */
  confianca: z.number().min(0).max(1),
  /** Distância CIEDE2000 do snap (auditoria) */
  delta_e: z.number().min(0),
  /** De onde veio a previsão final */
  fonte: z.enum(['snap_local', 'modelo_remoto', 'consenso']),
  /** Top 3 candidatos da paleta, para fallback de UI */
  candidatos: z.array(z.object({
    paleta_id: z.string(),
    delta_e: z.number(),
  })).max(3),
  warnings: z.array(z.string()).default([]),
});
export type AnalysisResult = z.infer<typeof AnalysisResultSchema>;
```

### 4.4 Pré-processamento e detecção de problemas

Em `src/lib/ai/preprocess.ts`:

| Verificação | Limiar | Ação |
|---|---|---|
| Imagem muito escura (média L < 18) | bloquear | toast "ambiente com pouca luz" |
| Warm cast severo (b\* médio > 25) | bloquear | toast "luz amarelada — vá para perto de uma janela" |
| Cool cast severo (b\* médio < -10) | aviso | toast "luz fria pode alterar leitura" |
| Cabelo molhado (saturação alta + L baixo) | aviso | toast "seque o cabelo para leitura precisa" |
| Pouco pixel de cabelo (<8% do frame) | bloquear | "aproxime mais a câmera do cabelo" |
| Excesso de highlights (L > 95 em > 25% dos pixels) | aviso | "evite reflexo direto da luz" |

### 4.5 Etapa "Human-in-the-loop"
Após a IA retornar, **sempre** mostrar uma tela de revisão com:
- Sliders editáveis para altura, % de brancos, reflexo.
- Os **top-3 candidatos** da paleta como botões alternativos ("Era esse?").
- Toda correção persiste em `analyses_corrections` no Supabase para futuro re-treino do modelo remoto.

### 4.6 Calibração de cor (crítico)
- Mostrar no onboarding **um cartão visual** explicando: luz natural, evitar amarelo de lâmpada, cabelo seco e penteado.
- Detector de warm cast bloqueia submissão severa (ver 4.4).
- **Futuro (não-MVP):** cartão de calibração gray-card impresso ou exibido em outro celular. Documentado, adiado.

### 4.7 Estratégias de IA por fase de maturidade do produto

| Maturidade | Estratégia de IA | Custo | Precisão esperada |
|---|---|---|---|
| **MVP (semana 1-4)** | Apenas pipeline local (segmentação MediaPipe + snap à paleta) | $0 | 60-70% top-1, 85% top-3 |
| **Beta (semana 5-12)** | Local + VLM remoto (Claude 4.5 Sonnet vision) com prompt estruturado citando a paleta. Roda só se confiança local < 0.7. | ~$0.003/inferência condicional | 75-85% top-1 |
| **GA (3+ meses, com dataset)** | Local + modelo fine-tuned (EfficientNet-B0) em dataset coletado das correções dos usuários. Hospedado em Replicate ou HF Endpoints. | ~$0.001/inferência | 90%+ top-1 |

> **Decisão registrada (D-005):** começamos **sem modelo treinado**. A heurística snap-to-paleta + segmentação + VLM remoto cobrem 80% dos casos. O dataset para fine-tuning é construído organicamente pelas correções dos usuários nas primeiras semanas. Isso evita gastar 2-4 semanas treinando antes do produto provar valor.

### 4.8 Custo e latência alvo
- Latência da camada local: **≤ 800ms** no celular médio (Pixel 5 / iPhone 11).
- Latência p95 da inferência remota: **≤ 2.5s**.
- Custo por inferência completa: **≤ US$ 0.003** (chamada remota só quando necessária).

---

## 5. Serviço de Colorimetria (`ColorimetriaService.ts`) — Pesquisa e Regras Canônicas

### 5.1 Por que reescrever do zero
O `coloracao_helper.dart` original retorna **string concatenada** — impossível de testar, internacionalizar ou evoluir. Faltam volumagem, proporção, gramas por comprimento, neutralização sistemática, regras de cobertura de brancos e avisos de segurança. A nova versão retorna **estrutura tipada baseada em pesquisa da indústria**.

### 5.2 Fundamentos teóricos (resumo executivo da pesquisa)

A pesquisa abaixo é baseada em manuais técnicos de L'Oréal Professionnel, Wella Koleston Perfect, Schwarzkopf Igora Royal, e literatura de colorimetria capilar profissional (Vidal Sassoon Academy, ABDC Brasil).

#### 5.2.1 Escala de altura de tom (1-12)
Padrão internacional Bürmann/CIELAB para colorimetria capilar:

| Nível | Nome | Pigmento natural dominante | L* aprox |
|---|---|---|---|
| 1 | Preto | Eumelanina densa | 5-10 |
| 2 | Castanho muito escuro | Eumelanina + traços de feomelanina | 10-15 |
| 3 | Castanho escuro | Eumelanina | 15-22 |
| 4 | Castanho médio (natural) | Eumelanina + feomelanina equilibradas | 22-30 |
| 5 | Castanho claro | Feomelanina aparece | 30-38 |
| 6 | Loiro escuro | Feomelanina dominante (laranja) | 38-46 |
| 7 | Loiro médio | Feomelanina (amarelo-laranja) | 46-54 |
| 8 | Loiro claro | Feomelanina (amarelo) | 54-62 |
| 9 | Loiro muito claro | Feomelanina (amarelo pálido) | 62-70 |
| 10 | Loiro claríssimo | Pouquíssima feomelanina | 70-78 |
| 11 | Super clareador | (alcançado só com descoloração) | 78-86 |
| 12 | Platinado | (alcançado só com descoloração intensiva) | 86-92 |

#### 5.2.2 Reflexos (segundo dígito após o ponto)
Convenção internacional adotada (varia ligeiramente por fabricante):

| Código | Reflexo | Pigmento adicionado | Uso típico |
|---|---|---|---|
| .0 | Natural | — | Cobertura base |
| .1 | Cinza/Azul (Ash) | Azul | Neutralizar laranja residual de clareamento |
| .2 | Violeta/Irisado | Violeta | Neutralizar amarelo residual; tons frios |
| .3 | Dourado | Amarelo intenso | Realçar quentura; mistura com .4 |
| .4 | Acobreado (Cobre) | Laranja | Ruivos quentes |
| .5 | Mogno/Caoba | Vermelho-violeta | Castanhos avermelhados |
| .6 | Vermelho | Vermelho puro | Ruivos intensos |
| .7 | Marrom (Matte) | Verde | Neutraliza vermelho; castanhos frios |
| .8 | Pérola/Bege | Azul-violeta dessat. | Loiros sofisticados |
| .9 | Profundo (natural intenso) | — | Cobertura intensa de brancos |

**Notação dupla** (ex: 7.43 = loiro médio acobreado-dourado): primeiro reflexo predomina, segundo modula.

#### 5.2.3 Lei das cores complementares (neutralização)
Físico-química do clareamento: ao subtrair eumelanina, expõem-se pigmentos remanescentes na sequência **vermelho → laranja → amarelo → amarelo pálido**. A neutralização usa cores opostas no círculo cromático:

| Pigmento residual exposto | Cor complementar | Reflexo a usar |
|---|---|---|
| Vermelho (clareamento de níveis 1-3) | Verde | .7 (matte) |
| Laranja (clareamento de níveis 4-6) | Azul | .1 (cinza) |
| Amarelo (clareamento de níveis 7-9) | Violeta | .2 (irisado) |
| Amarelo pálido (clareamento >9) | Violeta muito intenso | .22 ou pré-tonalizador violeta |

#### 5.2.4 Volumagem do oxidante (peróxido de hidrogênio)

| Vol | % H₂O₂ | Efeito sobre o cabelo |
|---|---|---|
| 10 vol | 3% | Não clareia. Tonalização, escurecimento, cobertura branca leve |
| 20 vol | 6% | Clareamento 1-2 níveis. Cobertura de brancos padrão |
| 30 vol | 9% | Clareamento 2-3 níveis. Usado com tintas oxidativas comuns |
| 40 vol | 12% | Clareamento 3+ níveis. **Reserva técnica** — pode danificar |

> **Regra de ouro:** **não pular mais de 3 níveis** com tintura oxidativa pura. Acima disso, requer pré-descoloração (pó descolorante + OX) para depois aplicar a tintura no tom desejado.

#### 5.2.5 Proporção tintura:oxidante

| Tipo de produto | Proporção | Observação |
|---|---|---|
| Tintura oxidativa padrão | 1:1.5 | 60g tinta + 90ml OX |
| Tintura para cobertura forte de brancos (.9, .0) | 1:1 | Mais pigmento |
| Super clareador (séries 11, 12, "High Lift") | 1:2 | 60g tinta + 120ml OX 30/40 vol |
| Tonalizante sem amônia | 1:2 | Sempre OX 10 vol |

#### 5.2.6 Quantidade por comprimento de cabelo

| Comprimento | Tintura (g) | Oxidante (ml @ 1:1.5) |
|---|---|---|
| Curto (até nuca) | 50g | 75ml |
| Médio (até ombros) | 70g | 105ml |
| Longo (até meio das costas) | 100g | 150ml |
| Muito longo (cintura+) | 150g | 225ml |

#### 5.2.7 Cobertura de brancos — regra de mistura

A cobertura de brancos sem rebote/aspecto "chapado" exige **mistura** com tom natural correspondente (.0), porque cabelo branco não tem pigmento residual e precisa de "fundamento":

| % Brancos | Estratégia |
|---|---|
| 0-30% | Tom desejado puro |
| 30-50% | 70% tom desejado + 30% tom natural (.0) da mesma altura |
| 50-70% | 50% tom desejado + 50% tom natural (.0) |
| 70-100% | 50% tom desejado + 50% tom **fundamental** (séries .0 ou .9). Considerar pré-pigmentação se reflexo for vermelho/cobre |

**Pré-pigmentação** (>70% brancos indo para tom vermelho/cobre): aplicar pigmento direto puro (sem OX) por 15min antes da fórmula principal, para "ancorar" a cor no fio sem pigmento.

#### 5.2.8 Tempo de pausa

| Cenário | Tempo |
|---|---|
| Tom sobre tom (sem clareamento) | 30 min |
| Clareamento 1-2 níveis | 35-40 min |
| Clareamento 3 níveis | 40-45 min |
| Cobertura de brancos | 45 min (raízes primeiro 15min, depois comprimento) |
| Super clareador | 50 min |
| Pré-pigmentação (pré-passo) | 15 min antes da mistura principal |

#### 5.2.9 Avisos de segurança obrigatórios

| Condição detectada | Aviso |
|---|---|
| Delta > 3 níveis com 40 vol | "Descoloração prévia recomendada — risco de dano severo" |
| Cabelo previamente descolorido + 30/40 vol | "Volumagem alta em cabelo já fragilizado pode causar quebra" |
| Brancos > 70% indo para vermelho/cobre sem pré-pigmentação | "Pré-pigmentação obrigatória para evitar rebote" |
| Subtom da pele vs reflexo escolhido divergente | "Subtom escolhido pode contrastar com seu tom de pele" |
| Primeira coloração + 40 vol | "Faça teste de mecha 48h antes" |

### 5.3 Saída do serviço (estrutura tipada completa)

```ts
export type Acao =
  | 'manter'                  // base === desejado, sem brancos significativos
  | 'tom_sobre_tom'           // delta = 0, com cobertura de brancos
  | 'escurecer'               // delta < 0
  | 'clarear_leve'            // delta = 1
  | 'clarear_medio'           // delta = 2
  | 'clarear_forte'           // delta = 3
  | 'descolorir_e_pigmentar'; // delta > 3

export type Volumagem = 10 | 20 | 30 | 40;
export type Subtom = 'frio' | 'neutro' | 'quente';
export type Comprimento = 'curto' | 'medio' | 'longo' | 'muito_longo';

export interface Diagnostico {
  base: number;                       // 1-12
  base_paleta_id: string;             // ex: "6.0"
  desejado: number;                   // 1-12
  desejado_paleta_id: string;         // ex: "8.1"
  brancos_pct: number;                // 0-100
  subtom_atual: Subtom;
  comprimento: Comprimento;
  cabelo_previamente_descolorido: boolean;
}

export interface Produto {
  /** Tipo do produto */
  tipo: 'tintura' | 'tonalizante' | 'pre_pigmentacao' | 'po_descolorante';
  /** ID/nome industrial — ex: "Tintura 8.1" */
  nome: string;
  /** Gramas a usar */
  quantidade_g: number;
  /** Percentual do total de tintura (útil para mistura de cobertura de brancos) */
  proporcao_pct: number;
  /** Observação livre */
  obs?: string;
}

export interface Oxidante {
  volumagem: Volumagem;
  percentual_h2o2: 3 | 6 | 9 | 12;
  quantidade_ml: number;
  proporcao_label: string;            // ex: "1:1.5"
}

export interface Passo {
  ordem: number;
  titulo: string;                     // ex: "Pré-pigmentação"
  descricao: string;                  // ex: "Aplicar pigmento direto..."
  tempo_min: number;                  // tempo desta etapa
}

export interface Aviso {
  severidade: 'info' | 'atencao' | 'critico';
  mensagem: string;
  /** Código para internacionalização e telemetria */
  codigo: string;                     // ex: "DELTA_EXCEDIDO"
}

export interface Formula {
  diagnostico: Diagnostico;
  acao: Acao;
  produtos: Produto[];
  oxidante: Oxidante;
  passos: Passo[];
  /** Soma de tempo_min dos passos principais (excl. pré-pigmentação) */
  tempo_pausa_total_min: number;
  avisos: Aviso[];
  /** Tom resultante esperado (paleta_id) — pode divergir de desejado em casos de delta >3 */
  resultado_esperado_paleta_id: string;
}
```

### 5.4 Regras canônicas em **tabelas** (`src/lib/colorimetria/rules.ts`)

> **Princípio:** **dados, não código**. O serviço só consulta. Stylist refina JSON sem mexer em TS.

```ts
import type { Volumagem, Subtom } from './types';

/**
 * Volumagem em função do delta de altura desejado.
 * delta = desejado - base.
 */
export const VOLUMAGEM_POR_DELTA: ReadonlyMap<number, Volumagem> = new Map([
  [-3, 10], [-2, 10], [-1, 10],
  [ 0, 10],
  [ 1, 20],
  [ 2, 30],
  [ 3, 40],
  // delta >= 4 dispara descoloração prévia (volumagem do descolorante = 30 vol padrão)
]);

/** Tabela de quantidades em gramas por comprimento. */
export const QUANTIDADE_BASE_G: Readonly<Record<string, number>> = {
  curto: 50,
  medio: 70,
  longo: 100,
  muito_longo: 150,
};

/** Multiplicador de proporção (volume OX / g de tintura). */
export const PROPORCAO_OX: Readonly<Record<string, number>> = {
  padrao: 1.5,                    // 1:1.5
  cobertura_brancos_forte: 1.0,   // 1:1
  super_clareador: 2.0,           // 1:2
  tonalizante: 2.0,               // 1:2
};

/** Mapa de cobertura de brancos: % brancos → mix [desejado, natural]. */
export interface MixCobertura {
  pct_desejado: number;   // ex: 0.7
  pct_natural: number;    // ex: 0.3
  exige_pre_pigmentacao_se_reflexo_em: ReadonlyArray<number>;
}
export const MIX_COBERTURA_BRANCOS: ReadonlyArray<{
  brancos_max: number;
  mix: MixCobertura;
}> = [
  { brancos_max: 30,  mix: { pct_desejado: 1.0,  pct_natural: 0.0, exige_pre_pigmentacao_se_reflexo_em: [] } },
  { brancos_max: 50,  mix: { pct_desejado: 0.7,  pct_natural: 0.3, exige_pre_pigmentacao_se_reflexo_em: [] } },
  { brancos_max: 70,  mix: { pct_desejado: 0.5,  pct_natural: 0.5, exige_pre_pigmentacao_se_reflexo_em: [4, 5, 6] } },
  { brancos_max: 100, mix: { pct_desejado: 0.5,  pct_natural: 0.5, exige_pre_pigmentacao_se_reflexo_em: [4, 5, 6] } },
];

/**
 * Neutralização de pigmento residual exposto pelo clareamento.
 * Mapeia o delta (níveis clareados) para o reflexo neutralizador sugerido,
 * quando o usuário escolhe reflexo .0 ou neutro.
 */
export const NEUTRALIZACAO_POR_DELTA: ReadonlyMap<number, { reflexo: number; descricao: string }> = new Map([
  [1, { reflexo: 7, descricao: 'Verde (.7) — neutraliza vermelho residual' }],
  [2, { reflexo: 1, descricao: 'Azul (.1) — neutraliza laranja residual' }],
  [3, { reflexo: 2, descricao: 'Violeta (.2) — neutraliza amarelo residual' }],
  [4, { reflexo: 2, descricao: 'Violeta intenso (.22) — amarelo pálido' }],
]);

/** Tempo de pausa em minutos por cenário. */
export const TEMPO_PAUSA_MIN: Readonly<Record<string, number>> = {
  tom_sobre_tom: 30,
  clarear_leve: 35,
  clarear_medio: 40,
  clarear_forte: 45,
  cobertura_brancos: 45,
  descolorir_e_pigmentar: 50,
  pre_pigmentacao: 15,
};
```

### 5.5 Algoritmo do serviço (`src/lib/colorimetria/service.ts`)

```ts
/**
 * Calcula a fórmula completa a partir do diagnóstico.
 * Pure function: mesmos inputs sempre geram mesma fórmula. Determinístico.
 * Lança ColorimetriaError em inputs inválidos.
 */
export function calcularFormula(diagnostico: Diagnostico, reflexoDesejado: number | null): Formula {
  // 1. Validar inputs (Zod no boundary, mas double-check defensivo aqui)
  // 2. delta = desejado - base
  // 3. Determinar acao (Acao) a partir do delta e dos brancos
  // 4. Selecionar volumagem (VOLUMAGEM_POR_DELTA)
  // 5. Selecionar proporção (PROPORCAO_OX) a partir do tipo de produto
  // 6. Calcular gramas/ml a partir de QUANTIDADE_BASE_G[comprimento]
  // 7. Aplicar MIX_COBERTURA_BRANCOS se brancos_pct > 0
  // 8. Se reflexoDesejado é null ou .0, e delta > 0, aplicar NEUTRALIZACAO_POR_DELTA
  // 9. Montar lista de produtos (incluir pré-pigmentação se aplicável)
  // 10. Montar passos numerados com tempos
  // 11. Coletar avisos
  // 12. Calcular resultado_esperado_paleta_id (snap do desejado à paleta)
  // 13. Retornar Formula
}
```

### 5.6 Testes obrigatórios (`vitest`, mínimo 20 casos)

Matriz de cobertura:

| # | Cenário | Inputs | Expectativa-chave |
|---|---|---|---|
| 1 | Manter tom sem brancos | base=6, desejado=6, brancos=0 | acao="manter", volumagem=10 |
| 2 | Tom sobre tom com brancos médios | base=6, desejado=6, brancos=40 | mix 70/30, volumagem=10 |
| 3 | Escurecer 2 níveis | base=8, desejado=6 | volumagem=10, ação="escurecer" |
| 4 | Clarear 1 nível | base=6, desejado=7 | volumagem=20 |
| 5 | Clarear 2 níveis | base=5, desejado=7 | volumagem=30 |
| 6 | Clarear 3 níveis | base=5, desejado=8 | volumagem=40, aviso "atenção" |
| 7 | Clarear 4 níveis (descolorir) | base=4, desejado=8 | acao="descolorir_e_pigmentar", produto inclui pó descolorante |
| 8 | Brancos 100% indo para 6.0 | base=6, desejado=6, brancos=100 | mix 50/50 com natural |
| 9 | Brancos 80% indo para 6.6 (vermelho) | brancos=80, desejado=6.6 | inclui passo de pré-pigmentação |
| 10 | Clareamento 2 sem reflexo escolhido | delta=2, reflexo=null | neutralização .1 (azul) automática |
| 11 | Clareamento 3 sem reflexo escolhido | delta=3, reflexo=null | neutralização .2 (violeta) automática |
| 12 | Comprimento longo | comprimento=longo | 100g tinta + 150ml OX |
| 13 | Comprimento muito longo + delta 2 | longo + delta=2 | 150g tinta + 225ml OX 30vol |
| 14 | Cabelo previamente descolorido + 30 vol | flag true | aviso "atencao" |
| 15 | Cabelo previamente descolorido + 40 vol | flag true + delta=3 | aviso "critico" |
| 16 | Super clareador (12.0) | desejado=12 | proporção 1:2, volumagem 40 |
| 17 | Tonalizante puro (mesmo tom) | base=8, desejado=8, brancos=0 | volumagem 10, proporção 1:2 |
| 18 | Inputs inválidos: base=0 | throw `ColorimetriaError` |
| 19 | Inputs inválidos: brancos=120 | throw |
| 20 | Inputs inválidos: desejado=13 | throw |

Cada teste valida estrutura completa, não só o campo central. Snapshot opcional para `Formula` completa.

### 5.7 Internacionalização (futuro)
Todos os textos dos passos, avisos e nomes de produtos vão por **código** (`PRE_PIGMENTACAO`, `DELTA_EXCEDIDO`, etc.), com a string em PT-BR resolvida no momento da renderização via dicionário em `src/lib/i18n/pt-br.ts`. Isso permite EN/ES no futuro sem refatorar a service.

---

## 6. Fluxo do Usuário (UX)

```
┌──────────┐   ┌─────────────┐   ┌──────────────┐   ┌────────────┐   ┌──────────┐
│ Landing  │ → │ Login/Cad.  │ → │ Onboarding   │ → │ Scanner    │ → │ Revisão  │
│ (Aurora) │   │ (Supabase)  │   │ (3 cards     │   │ (câmera +  │   │ (ajuste  │
│          │   │             │   │  glass)      │   │  Beams bg) │   │ sliders) │
└──────────┘   └─────────────┘   └──────────────┘   └────────────┘   └────┬─────┘
                                                                          │
                                                          ┌───────────────▼───────┐
                                                          │ Tom Desejado          │
                                                          │ (slider + preview cor)│
                                                          └───────────┬───────────┘
                                                                      │
                                                          ┌───────────▼───────────┐
                                                          │ Resultado (Magic Bento│
                                                          │  + CountUp + steps)   │
                                                          └───────────┬───────────┘
                                                                      │
                                                          ┌───────────▼───────────┐
                                                          │ Compartilhar/Salvar   │
                                                          │ (Capacitor Share)     │
                                                          └───────────────────────┘
```

---

## 7. Estrutura de Pastas (canônica)

```
hair-color-pro/
├── src/
│   ├── app/
│   │   ├── (marketing)/           # rotas públicas com Aurora bg
│   │   │   ├── layout.tsx
│   │   │   └── page.tsx           # landing
│   │   ├── (app)/                 # rotas autenticadas
│   │   │   ├── layout.tsx         # navbar glass + auth guard
│   │   │   ├── dashboard/page.tsx
│   │   │   ├── scanner/page.tsx
│   │   │   ├── review/page.tsx
│   │   │   ├── result/page.tsx
│   │   │   └── history/page.tsx
│   │   ├── auth/
│   │   │   ├── login/page.tsx
│   │   │   └── register/page.tsx
│   │   ├── api/
│   │   │   ├── analyze/route.ts   # POST imagem → IA
│   │   │   └── formula/route.ts   # POST diagnóstico → fórmula
│   │   ├── globals.css
│   │   ├── layout.tsx             # root: ThemeProvider, QueryProvider
│   │   └── manifest.ts            # PWA manifest
│   ├── components/
│   │   ├── ui/                    # shadcn (gerados pela CLI)
│   │   ├── bits/                  # efeitos reactbits.dev (copy-paste)
│   │   ├── glass/                 # wrappers próprios (GlassCard, GlassNav...)
│   │   ├── scanner/
│   │   │   ├── CameraView.tsx
│   │   │   └── CaptureOverlay.tsx
│   │   ├── review/
│   │   │   └── DiagnosticSliders.tsx
│   │   └── result/
│   │       ├── FormulaSteps.tsx
│   │       └── OxidanteCard.tsx
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts
│   │   │   └── server.ts
│   │   ├── ai/
│   │   │   ├── replicate.ts
│   │   │   ├── heuristic.ts       # fallback local
│   │   │   └── preprocess.ts      # sharp/canvas
│   │   ├── colorimetria/
│   │   │   ├── service.ts
│   │   │   ├── rules.ts
│   │   │   └── service.test.ts
│   │   ├── schemas/
│   │   │   └── analysis.ts        # Zod schemas
│   │   ├── stores/
│   │   │   └── session.ts         # Zustand
│   │   ├── feature-detect.ts
│   │   └── utils.ts               # cn() helper do shadcn
│   └── hooks/
│       ├── use-camera.ts
│       ├── use-analysis.ts        # TanStack Query
│       └── use-haptics.ts
├── public/
│   ├── icons/                     # PWA icons (192, 512, maskable)
│   └── reference-chart.png        # tabela visual de tons
├── tests/
│   ├── unit/
│   └── e2e/
├── ios/                           # gerado pelo Capacitor
├── android/                       # gerado pelo Capacitor
├── capacitor.config.ts
├── tailwind.config.ts             # opcional no Tailwind v4
├── next.config.mjs
├── tsconfig.json
├── package.json
└── .env.local.example
```

---

## 8. Roadmap de Implementação — Passo a Passo Bulletproof

> **Convenção**: cada fase tem (a) comandos, (b) saídas verificáveis, (c) **Definição de Pronto** (DoD). Não passar para a próxima fase sem cumprir a DoD.

### Fase 0 — Setup do repositório (½ dia)

**Comandos:**
```bash
pnpm create next-app@latest hair-color-pro \
  --typescript --tailwind --app --eslint --src-dir --import-alias "@/*"
cd hair-color-pro
pnpm add -D prettier prettier-plugin-tailwindcss husky lint-staged vitest \
  @testing-library/react @testing-library/jest-dom @vitejs/plugin-react jsdom
pnpm dlx husky init
```

**Arquivos a criar:**
- `.prettierrc.json` (com `plugins: ["prettier-plugin-tailwindcss"]`)
- `vitest.config.ts`
- `.env.local.example` com:
  ```
  NEXT_PUBLIC_SUPABASE_URL=
  NEXT_PUBLIC_SUPABASE_ANON_KEY=
  SUPABASE_SERVICE_ROLE_KEY=
  REPLICATE_API_TOKEN=
  REPLICATE_MODEL_VERSION=
  ```

**DoD:**
- [ ] `pnpm dev` abre em `localhost:3000` com página inicial.
- [ ] `pnpm test` roda (mesmo sem testes ainda) sem erro.
- [ ] Commit inicial passa por `lint-staged` (prettier + eslint).

---

### Fase 1 — Identidade visual (1.5 dias)

**Comandos:**
```bash
pnpm dlx shadcn@latest init   # tema custom; escolher "New York" style
# Componentes (rodar um por um para não falhar silenciosamente):
pnpm dlx shadcn@latest add button input label form card dialog sheet
pnpm dlx shadcn@latest add tabs badge avatar progress skeleton
pnpm dlx shadcn@latest add tooltip popover dropdown-menu sonner slider switch
pnpm add framer-motion motion next-themes zod react-hook-form @hookform/resolvers
```

**Arquivos a criar/editar:**
1. `src/app/globals.css` → colar bloco da **Seção 3.2** (design tokens + utilitários `.glass`).
2. `src/lib/feature-detect.ts` → detecção de `backdrop-filter`.
3. `src/components/glass/GlassCard.tsx` → wrapper que aplica `.glass` + props variant.
4. `src/components/glass/GlassNav.tsx` → top nav sticky com blur.
5. Variants nos componentes shadcn (`button.tsx`, `card.tsx`, `dialog.tsx`) — adicionar `glass` no `cva`.
6. `src/app/layout.tsx` → ThemeProvider (`next-themes`), Toaster (`sonner`), `<body className="bg-background text-foreground">`.

**Efeitos reactbits (Fase 1):**
- `src/components/bits/Aurora.tsx`
- `src/components/bits/ShinyText.tsx`
- `src/components/bits/GradientText.tsx`
- `src/components/bits/GlareHover.tsx`

> Para cada um: ir em reactbits.dev → copiar exatamente o componente (versão TS+Tailwind) → colar no arquivo correspondente → garantir que respeita `prefers-reduced-motion`.

**Tela entregue:** Landing page (`src/app/(marketing)/page.tsx`) com Aurora de fundo, headline com ShinyText, CTA com GlareHover, GlassCard com 3 features.

**DoD:**
- [ ] Landing roda com 60fps no Chrome desktop e em iPhone 12+.
- [ ] Lighthouse Performance ≥ 85 e Accessibility ≥ 95.
- [ ] Toggle dark/light funciona (mesmo que o tema principal seja dark — light deve existir).
- [ ] `prefers-reduced-motion: reduce` desliga Aurora e ShinyText.
- [ ] Visual review: comparar lado a lado com 3 prints do reactbits.dev — não devem parecer "diferentes".

---

### Fase 2 — Auth + estrutura de rotas (1 dia)

> **Sobre o Firebase legado**: o app antigo em Flutter usa Firebase Auth. **Não vamos migrar dados** porque (a) só há autenticação, sem perfil rico armazenado, e (b) o Supabase oferece RLS em Postgres que casa melhor com o histórico de análises + correções da IA. Avise os usuários existentes para recadastrar (são poucos no estado atual do app). Se a base de usuários crescer antes desta migração, trocar este passo por "Firebase Auth + Firestore" é viável — comentários inline no código indicam onde mudaria.

**Comandos:**
```bash
pnpm add @supabase/supabase-js @supabase/ssr
```

**Tarefas:**
1. Criar projeto no Supabase, copiar URL + anon key + service role key para `.env.local`.
2. `src/lib/supabase/client.ts` e `src/lib/supabase/server.ts` (padrão `@supabase/ssr`).
3. Schema inicial no Supabase (executar em SQL editor):
   ```sql
   create table profiles (
     id uuid primary key references auth.users on delete cascade,
     full_name text,
     created_at timestamptz default now()
   );
   create table analyses (
     id uuid primary key default gen_random_uuid(),
     user_id uuid references auth.users not null,
     image_path text not null,
     result jsonb not null,
     correction jsonb,
     created_at timestamptz default now()
   );
   create table formulas (
     id uuid primary key default gen_random_uuid(),
     analysis_id uuid references analyses on delete cascade,
     payload jsonb not null,
     created_at timestamptz default now()
   );
   -- RLS obrigatório:
   alter table profiles enable row level security;
   alter table analyses enable row level security;
   alter table formulas enable row level security;
   create policy "own profile" on profiles for all using (auth.uid() = id);
   create policy "own analyses" on analyses for all using (auth.uid() = user_id);
   create policy "own formulas" on formulas for all
     using (exists (select 1 from analyses a where a.id = analysis_id and a.user_id = auth.uid()));
   ```
4. Bucket Storage `hair-photos` privado.
5. Middleware Next.js (`src/middleware.ts`) que protege `(app)/*`.
6. Telas `auth/login` e `auth/register` usando shadcn `<Form>` + `react-hook-form` + `zod`. Visual GlassCard sobre Aurora.

**DoD:**
- [ ] Cadastro com email/senha cria registro em `profiles`.
- [ ] Tentar acessar `/dashboard` sem login redireciona para `/auth/login`.
- [ ] Logout limpa sessão e redireciona.
- [ ] RLS validada via SQL: query com user A não vê dados de user B.

---

### Fase 3 — Captura de imagem (1.5 dias)

**Comandos:**
```bash
pnpm add @tanstack/react-query zustand
```

**Tarefas:**
1. `src/hooks/use-camera.ts` — abstração que escolhe entre:
   - `@capacitor/camera` se `Capacitor.isNativePlatform()`
   - `navigator.mediaDevices.getUserMedia` no web
2. `src/components/scanner/CameraView.tsx` — preview ao vivo com overlay de crop circular para foco na raiz do cabelo.
3. Background da tela: `<Beams />` (reactbits) com opacidade baixa.
4. Botão de captura com `GlareHover`.
5. Onboarding (3 slides em `<Dialog>`) explicando: luz natural, distância 30cm, cabelo seco.
6. `src/lib/ai/preprocess.ts` — client-side: `<canvas>` para crop+resize → blob JPEG q=85.
7. Upload do blob → Supabase Storage (`hair-photos/{user_id}/{uuid}.jpg`).

**DoD:**
- [ ] Câmera funciona no Chrome desktop, Safari iOS, Chrome Android.
- [ ] Foto comprimida fica ≤ 200KB.
- [ ] Upload aparece no bucket do Supabase.
- [ ] Onboarding aparece só na primeira vez (flag em `@capacitor/preferences` ou `localStorage`).

---

### Fase 4 — IA: heurística local + integração remota (2 dias)

**Tarefas:**
1. `src/lib/ai/heuristic.ts` — implementação 100% client/server side usando `color-thief-node` (server) ou `colorthief` (browser):
   - Extrai paleta dominante (k=5).
   - Mapeia Lab médio para escala 1-12 via LUT (tabela em `src/lib/ai/lut.ts`).
   - Conta brancos via pixels com `L>85 && C<5`.
2. `src/app/api/analyze/route.ts`:
   - `multipart/form-data` parsing.
   - Pré-processa com `sharp` (resize 512, normaliza exposição).
   - Tenta Replicate; se falhar/timeout > 4s → cai na heurística.
   - Valida com `AnalysisResultSchema`.
   - Persiste em `analyses`.
3. `src/hooks/use-analysis.ts` — `useMutation` do TanStack Query.
4. Tela de loading com `<ScrambledText text="Analisando seu cabelo..." />` e `<BlurText />` na revelação.

**DoD:**
- [ ] Heurística retorna resultado válido em < 500ms para imagem 512x512.
- [ ] Remota retorna em < 3s p95 (medir com 50 inferências).
- [ ] Quando `REPLICATE_API_TOKEN` está vazio, sistema usa heurística e marca `fonte: 'heuristic'` no resultado.
- [ ] Erros de rede mostram toast e oferecem retry.

---

### Fase 5 — Revisão + Tom Desejado (1 dia)

**Tarefas:**
1. `src/app/(app)/review/page.tsx` — exibe resultado da IA em GlassCard.
2. `src/components/review/DiagnosticSliders.tsx` — 3 sliders shadcn:
   - Altura de tom (1-12) com swatch de cor ao lado.
   - % de brancos (0-100) com CountUp.
   - Subtom (segmented control: frio / neutro / quente).
3. Quando o usuário ajusta, salvar correção no Supabase para futuro re-treino.
4. Tela seguinte: escolha do tom desejado com **preview visual** (gradiente da cor estimada).

**DoD:**
- [ ] Sliders refletem instantaneamente swatch de cor.
- [ ] Correções persistem em `analyses.correction`.
- [ ] Botão "calcular fórmula" só habilita com tom desejado preenchido.

---

### Fase 6 — Serviço de Colorimetria + tela de Resultado (1.5 dias)

**Tarefas:**
1. Implementar `src/lib/colorimetria/service.ts` + `rules.ts` conforme Seção 5.
2. Escrever testes em `src/lib/colorimetria/service.test.ts` cobrindo os 12 casos.
3. `src/app/api/formula/route.ts` recebe diagnóstico, chama serviço, persiste em `formulas`.
4. `src/app/(app)/result/page.tsx`:
   - Header com `<GradientText>` no número do tom alvo.
   - `<MagicBento>` com 4 cards: Diagnóstico / Produtos / Oxidante / Passos.
   - `<CountUp>` na volumagem e proporção.
   - `<AnimatedList>` nos passos.
   - Botão "Compartilhar" → `@capacitor/share` no nativo, `navigator.share` no web.
5. Histórico (`/history`) lista análises anteriores em cards glass com TiltedCard.

**DoD:**
- [ ] `pnpm test` passa todos os 12+ casos de `service.test.ts`.
- [ ] Resultado renderiza corretamente para os 6 fluxos canônicos (matriz: base × desejado × brancos baixos/altos).
- [ ] Compartilhar gera card visual (imagem PNG) com a fórmula — usar `html-to-image`.

---

### Fase 7 — PWA + Capacitor (1 dia)

**Comandos:**
```bash
pnpm add @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
pnpm add @capacitor/camera @capacitor/preferences @capacitor/haptics @capacitor/share
pnpm dlx cap init "Hair Color Pro" com.haircolorpro.app --web-dir=out
```

**Tarefas:**
1. Configurar `next.config.mjs` com `output: 'export'` (ou `'standalone'` se preferir SSR — mas Capacitor exige static).
2. `src/app/manifest.ts` — name, theme color, icons (192/512/maskable em `public/icons/`).
3. Service worker via `next-pwa` ou `@serwist/next`.
4. `cap add ios && cap add android`.
5. `capacitor.config.ts` com `appId`, `appName`, `webDir: 'out'`.
6. Testar build nativo: `pnpm build && cap sync && cap open ios`.

**DoD:**
- [ ] PWA instala no Chrome desktop e mobile.
- [ ] Build iOS roda no simulator com câmera funcionando.
- [ ] Build Android roda no emulator com câmera funcionando.
- [ ] Splash screen e ícone aparecem corretamente.

---

### Fase 8 — Polimento, testes E2E, lançamento (1.5 dias)

**Comandos:**
```bash
pnpm add -D playwright @playwright/test
pnpm dlx playwright install
```

**Tarefas:**
1. Testes E2E em `tests/e2e/`:
   - Flow completo: login → scanner → IA mock → revisão → resultado.
   - Tema dark/light persiste.
   - `prefers-reduced-motion` desabilita efeitos.
2. Otimizações:
   - `next/image` em todas as imagens.
   - Fontes via `next/font`.
   - Code-split dos efeitos `bits/*` com `dynamic(() => import('...'), { ssr: false })`.
3. Lighthouse audit: Performance ≥ 90 mobile, Accessibility 100, SEO ≥ 90.
4. Telemetria mínima: Sentry ou PostHog para erros e funil.

**DoD:**
- [ ] Suite E2E verde no CI.
- [ ] Sem warnings de React no console em produção.
- [ ] Bundle inicial ≤ 200KB gzipped.

---

## 9. Variáveis de Ambiente (todas obrigatórias)

`.env.local.example` (commitado) e `.env.local` (gitignored):

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# IA
REPLICATE_API_TOKEN=
REPLICATE_MODEL_VERSION=         # ex: "f1d50bf24f...:version"
# OU, se for Hugging Face:
HUGGINGFACE_API_TOKEN=
HUGGINGFACE_MODEL_ID=

# Feature flags
NEXT_PUBLIC_ENABLE_BITS=true     # liga/desliga efeitos pesados
NEXT_PUBLIC_FORCE_HEURISTIC=false

# Telemetria (opcional)
NEXT_PUBLIC_SENTRY_DSN=
```

Validar em `src/lib/env.ts` com Zod — falhar em build se algo crítico faltar.

---

## 10. Definição de Pronto (Geral)

O projeto é considerado pronto para entrega quando:

- [ ] Todos os DoDs das Fases 0–8 estão marcados.
- [ ] `pnpm typecheck`, `pnpm lint`, `pnpm test`, `pnpm test:e2e` passam sem erros.
- [ ] Lighthouse mobile: Performance ≥ 90, Accessibility = 100, Best Practices ≥ 95.
- [ ] Comportamento gracioso quando há rede instável: heurística entra como fallback, toast informativo aparece, retry manual disponível. (Não confundir com "funciona offline" — login e IA principal exigem internet.)
- [ ] Build iOS e Android passam revisão técnica básica das lojas (sem warnings de privacidade — privacy policy + `NSCameraUsageDescription` configurados).
- [ ] README atualizado com instruções de setup, env vars e deploy.

---

## 11. Riscos & Mitigações

| Risco | Probabilidade | Impacto | Mitigação |
|---|---|---|---|
| Modelo de IA tem precisão baixa no início | Alta | Alto | Tela de revisão sempre obrigatória; coletar correções para re-treino |
| `backdrop-filter` ruim em Android antigo | Média | Médio | `feature-detect.ts` + fallback sólido |
| Cold start Replicate > 10s | Alta | Médio | Cron de keep-warm OU mover para HF Inference Endpoints dedicated |
| Custo de IA escalando com adoção | Média | Médio | Cache de inferência por hash de imagem; rate-limit por user |
| Capacitor build falha em iOS | Média | Alto | Pinning de versão `@capacitor/ios@6.x`; documentar Xcode mínimo no README |
| Performance dos efeitos reactbits em mobile baixo-fim | Alta | Médio | Flag `NEXT_PUBLIC_ENABLE_BITS`; detecção de `navigator.deviceMemory` |

---

## 12. Glossário

- **Altura de tom**: escala 1 (preto) a 12 (loiro clarissimo platinado) usada na colorimetria capilar.
- **Reflexo / nuance**: dígito após o ponto (ex: 6.1 = loiro escuro acinzentado).
- **Subtom**: temperatura dominante percebida (frio/neutro/quente).
- **Volumagem do OX**: concentração do oxidante (10, 20, 30, 40 vol.) — determina poder de clareamento.
- **Pré-pigmentação**: aplicar pigmento de base antes da cor final em cabelos muito brancos.
- **DoD**: Definition of Done — critérios objetivos de fim de fase.
- **RSC**: React Server Component (padrão no App Router do Next 15).

---

## 13. Log de Decisões Tomadas em Implementação

Cada decisão arquitetural tomada pelo executor (humano ou IA) durante a implementação **deve ser registrada aqui** com data, código e justificativa. Isso evita "por que isso está assim?" no futuro.

| Código | Data | Decisão | Justificativa |
|---|---|---|---|
| D-001 | 2026-05-11 | Paleta cobre sobre carvão quente (substituindo violeta/magenta/ciano) | Referência direta à indústria; evita "cara de IA"; contrasta com glass dark |
| D-002 | 2026-05-11 | Reduzir efeitos reactbits a 8 curados; rejeitar SplashCursor, MagicBento neon, Beams, Scrambled/Decrypted, PixelTransition | Anti-vibe-coding; foco em elegância corporativa |
| D-003 | 2026-05-11 | Geist Sans default; Instrument Serif apenas em 1 hero por tela | Hierarquia tipográfica controlada |
| D-004 | 2026-05-11 | IA usa "snap-to-palette" (k-NN sobre paleta de 120 entradas em Lab) em vez de regressão livre | Determinismo, auditabilidade, custo zero no local |
| D-005 | 2026-05-11 | MVP roda sem modelo treinado; usa heurística + VLM remoto condicional | Evita 4 semanas treinando antes de provar valor |
| D-006 | 2026-05-11 | Dark mode only no MVP; light mode adiado para Fase 9+ | Cabeleireiros trabalham em iluminação controlada |
| D-007 | 2026-05-11 | Não migrar usuários do Firebase legado; pedir recadastro | Base pequena, evita semanas portando hash de senha |
| D-008 | 2026-05-11 | Projeto Next.js fica em `v2/` no monorepo atual; Flutter preservado em `/lib`, `/android`, etc. como referência | Não-destrutivo durante migração; user pode promover `v2/` ao root quando aprovar |
| D-009 | 2026-05-11 | Provedor inicial de IA remoto: Anthropic Claude 4.5 Sonnet (vision) com structured output. Replicate fica documentado como upgrade quando dataset for grande | Sem custo de treino; structured output Zod-compatible; latência aceitável; o modelo conhece a paleta em prompt |
| D-010 | 2026-05-11 | Categorias da paleta de referência limitadas a: natural/loiro/ruivo/mogno/vermelho/matte/pérola. Fantasia (rosa/azul/verde) **fora do MVP** | Manter espectro restrito e produto focado |
| D-011 | 2026-05-11 | Crédito ao salão **Jotta Lean Cabelos** mantido em produção em 3 pontos: footer da landing, metadata SEO (`publisher`), README do projeto | Origem real do produto. Cabeleireiros confiam mais em ferramentas nascidas no salão. Crédito é discreto (footer monocromático + metadata), não comercial — não vira logotipo nem ocupa espaço no fluxo principal |

> **Como adicionar uma nova entrada:** ao tomar uma decisão arquitetural não-trivial, adicione linha com `D-NNN`, data ISO, descrição curta e justificativa. Se reverter uma decisão, mantenha a entrada original e adicione nova decisão revertendo.

---

## 14. Apêndice — Comandos de referência rápida

```bash
# dev
pnpm dev

# build web + PWA
pnpm build

# sync mobile shells
pnpm build && pnpm dlx cap sync

# abrir Xcode
pnpm dlx cap open ios

# abrir Android Studio
pnpm dlx cap open android

# testes
pnpm test          # unit
pnpm test:e2e      # playwright

# lint/format
pnpm lint
pnpm format
```
