# PROGRESSO — Hair Color Pro v2

> Este arquivo é o **bastão de transmissão**. Toda vez que um executor avança,
> atualiza esta página. Quem pegar depois lê só este arquivo + `PLAN.md`.

**Última atualização:** 2026-05-13 (sessão Claude 5 — Bloco F + tooltips + documentação TG)
**Próximo executor:** humano ou nova sessão de Claude
**Arquivos obrigatórios antes de continuar:**
1. `.planning/PLAN.md`
2. `.planning/ARQUITETURA_JUSTIFICATIVA.md`
3. Este `.planning/PROGRESSO.md`
4. `v2/README.md`
5. **`v2/PROJECT.md`** ← novo, documentação arquitetural profunda

---

## ✅ Sessão 5 (Claude, 2026-05-13) — Bloco F + tooltips + documentação TG

### Bloco F (análise + IA) implementado
- **`src/lib/colorimetria/image-analysis.ts`** — pipeline determinístico:
  - Recebe `ImagePixels` (RGBA contínuo) e máscara opcional
  - Converte pixels → Lab, classifica branco/grisalho vs colorido vs ruído
  - Calcula Lab médio dos pixels coloridos
  - `findClosestPaletteEntry` → snap-to-palette via ΔE2000
  - `classificarSubtom` via componente `a` do Lab
  - `computarConfianca` via `1 - tanh(ΔE/12)`
- **`src/lib/ai/report.ts`** — integração Claude 3.5 Sonnet:
  - System prompt de "cabeleireira sênior, 30 anos de cadeira"
  - User prompt com diagnóstico numérico determinístico
  - Estrutura fixa: 3 parágrafos (diagnóstico → interpretação → cuidado)
  - **`gerarRelatorioFallback`** — template offline, garantido determinístico, usado quando API falha ou sem `ANTHROPIC_API_KEY`
- **`src/app/api/analyze/route.ts`** — Route Handler completo:
  - Valida payload (Zod), decodifica base64 → RGBA
  - Roda `analyzeImageColor` + `gerarRelatorio` + `insertAnalysis`
  - Devolve `{ analysisId, analysis, report }`
- **`src/app/(app)/result/page.tsx`** — tela de resultado:
  - Card hero com swatch + nome serif italic + código colorimétrico
  - 3 chips de métricas (subtom, brancos, confiança) com ícone de severidade
  - Card "Parecer profissional" com texto gerado (3 parágrafos)
  - Detalhes técnicos expansíveis (ΔE, modelo, tokens)
  - Modo demo via `/result?demo=1` (sem precisar da câmera real)

### Tooltips com explicação ao toque
- **`src/components/app/CaptureTipsChips.tsx`** — chips "Luz natural" e "30 cm" com Popover (Radix) ao toque:
  - Luz natural → explicação técnica (luz branca difusa, perto de janela; evitar sol direto, luz amarelada, flash)
  - 30 cm → explicação (área grande de cabelo, não fios individuais)
- Substitui as chips passivas do scanner por essas interativas

### Documentação acadêmica completa do TG
Diretório novo `v2/docs/tg/` com 8 arquivos, ~1300 linhas:
- `README.md` — índice + instruções pra converter pra PDF via Pandoc
- `00-RESUMO.md` — abstract executivo PT/EN
- `01-INTRODUCAO.md` — contexto Jotta Lean, motivação, objetivos, justificativa
- `02-FUNDAMENTACAO.md` — escala 1-12 + reflexos + sRGB/Lab/CIEDE2000 + PWA + IA generativa
- `03-METODOLOGIA.md` — blocos de desenvolvimento + stack + decisões (Next vs SPA, Firebase vs Supabase, Claude vs GPT vs Gemini)
- `04-IMPLEMENTACAO.md` — código real comentado (capítulo mais denso, 490 linhas)
- `05-RESULTADOS.md` — bundle sizes, tempos de resposta, custos, limitações
- `06-CONCLUSAO.md` — síntese, contribuições, limitações, 8 trabalhos futuros
- `07-REFERENCIAS.md` — bibliografia ABNT 6023:2018

### Performance final
```
Build: 4-6s | Prod start: 270ms | Bundle landing: 126kB
Resposta servidor: 1-2ms (cache warm)
Análise determinística: ~50ms imagem 1024×1024
Pipeline completo c/ Claude: ~2.150ms
Custo por análise: $0.0078 USD
```

### Decisão D-016 — IA como camada de comunicação, não motor de decisão
- **Reconhecimento de cor**: 100% algoritmo (ΔE2000 + paleta) — determinístico, auditável, ~50ms, $0
- **Geração de relatório**: 100% Claude — natural, profissional, ~2s, $0.008
- Padrão aplicável a domínios onde rigor numérico e linguagem humana coexistem (medicina, direito, contabilidade)

---

## ✅ Sessão 4 (Claude, 2026-05-12) — PWA real + performance + UX

### Migração Supabase → Firestore
Supabase removido por completo. DB agora 100% Firebase (Firestore Admin SDK).
- `src/lib/firestore/index.ts` — CRUD typed com resiliência (`safeRead`/`safeWrite` trata códigos gRPC 5/7/9)
- `src/lib/firestore/types.ts` — `ProfileDoc`, `AnalysisDoc`, `FormulaDoc`
- `src/app/api/profile/route.ts` — GET/PATCH com auth
- `getAnalyses` sem `orderBy` server-side (não exige índice composto)
- `supabase/migrations/`, `src/lib/supabase/` — deletados
- `@supabase/*` deps removidas do package.json

### PWA install **real** (não atalho)
Antes virava só atalho. Agora instala como app standalone:
- **8 ícones PNG** (192/512/maskable/apple-touch/favicon) via `pnpm icons` (sharp)
- **8 splash screens iOS** por resolução (iPhone 15 Pro Max → SE → iPad Pro 12") via `pnpm splash`
- **Service Worker** em `public/sw.js` — fetch handler com cache + offline shell. Critério Chrome PWA install.
- **`ServiceWorkerRegister`** Client Component registra `/sw.js`
- **Manifest** com `display_override: ["fullscreen", "standalone", "minimal-ui"]`, shortcuts, ícones any+maskable
- **Apple touch icon + 8 startup images** via `<link>` no `<head>`
- **InstallHint** = banner flutuante chamativo (estilo poker-odds-calculator) com animate-pulse, dismissable em sessionStorage. Lazy-loaded via `next/dynamic ssr:false`.

### Status bar fuse
Eliminada (ou quase) a costura visível entre status bar Android e conteúdo:
- `theme_color` e `--color-background` ambos = `#0E0C0B` literal
- Body `bg-[#0E0C0B]` hardcoded
- Div fixo no topo do `<body>` com cor sólida + `height: max(env(safe-area-inset-top), 8px)`
- Aurora com `mask-image: linear-gradient(to bottom, transparent 0 160px, black 220px, ...)`

### Performance — 10× a 2000× ganhos
- **Cache de `verifySessionCookie`** em memória, hash FNV-1a, TTL 60s → cada nav agora vale 1 round-trip Firebase em vez de N
- **Eliminada verificação JWT dupla** (middleware faz, layout só checa cookie O(1))
- **`AuroraStatic`** Server Component (zero JS) em scanner/history/profile
- **`InstallHintLazy`** via `next/dynamic ssr:false` — não bloqueia first paint
- **`loading.tsx`** em `(app)/*` e `auth/*` — skeleton instantâneo
- **Prefetch agressivo** em todos os `<Link>` críticos
- **View Transitions API** ativada (`experimental.viewTransition: true`) + CSS fade 180ms
- **Middleware early-return** pra rotas públicas e assets PWA
- **Removidas deps**: `@tanstack/react-query`, `framer-motion` (não usadas) — -100MB node_modules
- **`optimizePackageImports`** estendido: radix primitives, sonner, lucide-react
- **Bundle final**: 115kB shared, landing 1kB, auth 4kB, profile 4kB

### UX / Visual
- **Greeting personalizada** no /scanner: "Olá, {firstName}" (vem do session cookie)
- **3 anéis pulsantes** no viewfinder (3s, desfasados)
- **Avatar com inicial** no /profile (círculo cobre + ring)
- **Empty state visual** no /history (ícone em círculo cobre + texto centrado)
- **Header com counter dinâmico** ("3 análises", "Nenhuma análise")
- **Error boundary global** (`app/error.tsx`) com ref ID em prod
- **404 customizada** (`app/not-found.tsx`) com identidade visual
- **Banner de instalação** flutuante, animate-pulse, dismissable
- **AppNav com pílula ativa** (`bg-primary/10 ring-primary/20` no item ativo)
- **Botões com `active:scale-[0.97]`** universal — feedback tátil
- **Tamanho `touch`** (h-12) — padrão Apple HIG ≥44px

### SEO / Share
- **OG image dinâmica** (1200×630) em `app/opengraph-image.tsx` via Satori (edge runtime)
- **robots.txt** via `app/robots.ts`
- **sitemap.xml** via `app/sitemap.ts`
- **Open Graph + Twitter cards** completos

### Headers HTTP
- `/manifest.webmanifest`, `/icon-*.png`, `/apple-touch-icon.png`, `/splash-*.png`, `/icon*.svg`, `/favicon-*.png`:
  - `Cache-Control: public, max-age=604800, s-maxage=2592000, stale-while-revalidate=86400`
- `/sw.js`: `public, max-age=0, must-revalidate` (sempre fresh)

### Documentação criada
- **`v2/README.md`** — reescrito completamente
- **`v2/PROJECT.md`** — documentação arquitetural profunda (decisões, fluxos, troubleshooting, glossário)
- Comentários ricos em todos os arquivos novos explicando "por quê", não "o quê"

### Performance medida
```
Tempos de resposta (localhost, prod):
  /                      2ms
  /auth/login            2ms
  /auth/register         2ms
  /scanner               1ms   ← com session cache hot
  /history               1ms
  /profile               1ms

Bundle:
  Shared base            115 kB
  Landing                 +1 kB → 126 kB total
  Auth login/register    +4 kB → 199 kB total
  Profile                +4 kB → 195 kB total
  Scanner/History        +0 kB → 115 kB total
```

### Comandos novos
- `pnpm icons` — regera 6 ícones PNG (sharp) a partir de `public/icon.svg`
- `pnpm splash` — regera 8 splash screens iOS

### Decisão D-013 — Firestore em vez de Supabase
- **Mantém compatibilidade com app Flutter** (mesmos usuários)
- Auth + DB no mesmo projeto Firebase = sem hacks de service_role
- NoSQL é suficiente pro caso de uso (perfil, análises, fórmulas — sem joins complexos)
- Resiliência: queries safe contra Firestore desabilitado/sem índice/sem permissão

### Decisão D-014 — display_override fullscreen + status bar fuse
- Tentativa de aproximar PWA Android ao "edge-to-edge" do Flutter
- Limitação: web pura não consegue status bar transparente sobreposta — solução real é Capacitor (Bloco H)
- Atual: cor sólida idêntica entre system bar e app top → costura imperceptível

### Decisão D-015 — Cloudflared pra testar PWA local
- Chrome Android exige HTTPS pra dispar `beforeinstallprompt`
- LAN IP (`10.0.0.x`) considerado insecure → só vira atalho
- Tunnel HTTPS efêmero resolve sem cadastro: `cloudflared tunnel --url http://localhost:3000`

---

## Sessões anteriores

---

## Sumário do estado

| Camada | Status | Arquivos |
|---|---|---|
| Documentação arquitetural | ✅ Completa | `.planning/PLAN.md`, `ARQUITETURA_JUSTIFICATIVA.md`, este arquivo |
| Scaffold Next.js | ✅ Completo | configs, tsconfig, next.config, postcss, vitest, env example |
| Design system (globals.css, glass utils) | ✅ Completo | `globals.css` (paleta cobre/carvão, glass, keyframes accordion) |
| Domínio colorimetria (types, rules, math, palette, service) | ✅ Completo | `src/lib/colorimetria/*` — 24 testes passando |
| Schemas Zod (analysis + auth) | ✅ Completo | `src/lib/schemas/*` |
| Hook `useReducedMotion` | ✅ Completo | `src/hooks/use-reduced-motion.ts` |
| Hook `useAuth` (Firebase) | ✅ Completo | `src/hooks/use-auth.ts` |
| shadcn/ui — 22 componentes | ✅ Completo | `src/components/ui/*` (glass/copper variants extras) |
| Efeitos visuais (Aurora, ShinyText, GradientText, GlassCard) | ✅ Completo | `src/components/bits/*`, `src/components/glass/*` |
| **Firebase Auth** | ✅ **Completo** | `src/lib/firebase/client.ts`, `admin.ts` |
| **API route de sessão** | ✅ **Completo** | `src/app/api/auth/session/route.ts` |
| **Middleware (Firebase session cookie)** | ✅ **Completo** | `src/middleware.ts` |
| **Telas de auth (Firebase)** | ✅ **Completo** | `src/app/auth/login/page.tsx`, `register/page.tsx`, `layout.tsx` |
| **Shell protegido (Firebase)** | ✅ **Completo** | `src/app/(app)/layout.tsx` verifica session cookie Firebase |
| Navegação inferior (AppNav) | ✅ Completo | `src/components/app/AppNav.tsx` |
| ~~Supabase DB~~ | 🚫 Removido (D-013) | substituído por Firestore |
| **Firestore Admin (CRUD typed + resiliência)** | ✅ **Completo** | `src/lib/firestore/index.ts`, `types.ts` |
| **API route `/api/profile`** | ✅ **Completo** | GET/PATCH com auth |
| Telas estruturais (scanner, history, profile) | ✅ **Polidas** | greeting personalizada, avatar, empty states, counter dinâmico |
| Componentes app (ProfileForm) | ✅ Completo | usa `/api/profile` (não mais Supabase client) |
| Fontes next/font | ✅ Completo | Geist + Instrument Serif no `layout.tsx` |
| Landing | ✅ Polida | h-dvh sem scroll, CTAs claros, footer centrado |
| **PWA install real** | ✅ **Completo** | manifest + SW + 6 PNG icons + 8 splash iOS |
| **Status bar fuse** | ✅ **Completo** | cor sólida `#0E0C0B` literal em 3 camadas |
| **Error boundary global** | ✅ **Completo** | `app/error.tsx` com fallback amigável |
| **404 customizada** | ✅ **Completo** | `app/not-found.tsx` |
| **OG image dinâmica** | ✅ **Completo** | `app/opengraph-image.tsx` via Satori |
| **robots.txt + sitemap.xml** | ✅ **Completo** | `app/robots.ts`, `app/sitemap.ts` |
| **Performance** | ✅ **Otimizada** | cache session 60s, prefetch, View Transitions, AuroraStatic |
| **Headers HTTP cache** | ✅ **Completo** | 7d browser + 30d CDN pra assets PWA |
| Camada de IA (snap, segmentação, remoto) | ⬜ Não iniciado (Bloco E/F) | `src/lib/ai/*` |
| API routes (`/api/analyze`, `/api/formula`) | ⬜ Não iniciado (Bloco F) | |
| Telas completas (scanner + câmera, review, result) | ⬜ Não iniciado (Bloco D/G) | |
| Capacitor (iOS/Android) | ⬜ Não iniciado (Bloco H) | |
| Testes E2E | ⬜ Não iniciado (Bloco I) | |

Legenda: ✅ Completo · 🟡 Parcial · ⬜ Não iniciado

---

## ✅ O que foi feito — sessão 3 (Claude, 2026-05-11)

### Instalação e build

- **pnpm instalado** via Homebrew (`brew install pnpm` — era o `zsh: command not found: pnpm`).
- **`pnpm install`** executado com sucesso (deps + build scripts aprovados).
- **24/24 testes passando** · **zero erros TypeScript** após esta sessão.

### Decisão D-012 — Firebase Auth em vez de Supabase Auth

O app Flutter já usava Firebase Auth (projeto `arte-de-colorir-cabelos`, email/password).
Para manter compatibilidade com usuários existentes (sem re-cadastro), a auth do Next.js v2
usa o mesmo projeto Firebase. O Supabase continua sendo usado **apenas para o banco de dados**
(tabelas `analyses`, `profiles`, `formulas`).

**Arquitetura final de auth:**
```
Browser                 Next.js Server             Firebase
──────                  ──────────────             ────────
signInWithEmail()  ──►  /api/auth/session  ──►  verifyIdToken()
  ↓ ID Token             ↓ cria cookie              ↓ claims (uid, email)
                     __firebase_session
                     (HttpOnly, 5 dias)

middleware.ts  ──►  verifySessionCookie()  ──►  Firebase Admin SDK
                    (verifica a cada req)
```

**Por que não usar Firebase para DB também?**
O Supabase foi mantido para DB porque: (1) o schema SQL está pronto e tem RLS; (2) melhor
suporte a TypeScript com `gen types`; (3) dados são relacionais (analyses FK para users).
O Firebase UID é usado como FK primária nas tabelas Supabase (`profiles.id = firebase_uid`).

### Arquivos criados/modificados

- `src/lib/firebase/client.ts` — SDK browser: `getFirebaseAuth()` singleton, config do projeto
- `src/lib/firebase/admin.ts` — SDK servidor: `verifyIdToken()`, `createSessionCookie()`, `verifySessionCookie()`
- `src/app/api/auth/session/route.ts` — POST (ID token → cookie 5d) + DELETE (logout)
- `src/middleware.ts` — reescrito para Firebase: `verifySessionCookie()`, runtime nodejs
- `src/app/auth/login/page.tsx` — reescrito: `signInWithEmailAndPassword` + session cookie
- `src/app/auth/register/page.tsx` — reescrito: `createUserWithEmailAndPassword` + `updateProfile` + cookie
- `src/app/(app)/layout.tsx` — reescrito: verifica cookie Firebase (não Supabase session)
- `src/app/(app)/profile/page.tsx` — usa `claims.uid` do Firebase como user ID
- `src/components/app/ProfileForm.tsx` — logout Firebase (`signOut`) + apaga cookie (`DELETE /api/auth/session`)
- `src/hooks/use-auth.ts` — `useAuth()` hook: `onAuthStateChanged` para Client Components
- `.env.local.example` — atualizado: vars Firebase (NEXT_PUBLIC_* + server-only) + Supabase DB
- `src/lib/supabase/client.ts` e `server.ts` — removido generic `Database` (não compatível com supabase-js v2.105 sem `gen types`)
- `src/app/(app)/history/page.tsx` e `profile/page.tsx` — type assertions explícitas `as Tables<'T'>`
- `src/components/app/ProfileForm.tsx` — type assertion `TablesUpdate<'profiles'>` como workaround

### TypeScript fixes

- Adicionado `CookieOptions` import explícito em `server.ts` e `middleware.ts`
- Adicionado `CompositeTypes: Record<string, never>` ao `Database` type (exigido pelo supabase-js v2.105+)
- Adicionado `Relationships: []` em cada tabela (`GenericTable` exige o campo)
- Removido generic `<Database>` dos clientes Supabase (workaround para until `supabase gen types`)

---

## ⬜ O que falta — roteiro priorizado

### 🔥 PRÓXIMO: Configurar o Firebase Console

O `NEXT_PUBLIC_FIREBASE_API_KEY` está vazio no `.env.local.example`.
Sem ele, o login não funciona.

```
1. Acessar: console.firebase.google.com → projeto arte-de-colorir-cabelos
2. Project Settings → Your apps → Web app (ID: 1:205375342353:web:b07166e0699c88dc1d2eb0)
   → Copiar "apiKey" para NEXT_PUBLIC_FIREBASE_API_KEY em .env.local
3. Project Settings → Service accounts → Generate new private key → baixar JSON
   → Copiar client_email para FIREBASE_CLIENT_EMAIL
   → Copiar private_key para FIREBASE_PRIVATE_KEY (incluir as aspas e \n)
4. Authentication → Settings → Authorized domains → adicionar localhost
5. rodar: pnpm dev → testar /auth/login com email/senha do Flutter
```

### Bloco C.6 — Configurar Supabase (banco de dados)

```
1. supabase.com → criar projeto
2. Copiar URL e anon key para .env.local (NEXT_PUBLIC_SUPABASE_URL etc.)
3. SQL Editor → executar v2/supabase/migrations/001_initial_schema.sql
4. Storage → criar bucket 'analyses' (privado)
5. IMPORTANTE: a trigger handle_new_user está no SQL mas o usuário criado pelo Firebase
   não passa pelo Supabase Auth. Portanto, o perfil deve ser criado manualmente na
   primeira vez que o usuário acessa o app (upsert no profile page ou em /api/auth/session).
```

> **Nota sobre Firebase UID no Supabase:** A tabela `profiles` tem `id UUID REFERENCES auth.users(id)`.
> No nosso setup, `auth.users` do Supabase não existe (não usamos Supabase Auth).
> **Alterar o SQL:** remover a FK `REFERENCES auth.users(id)` de `profiles` e deixar apenas
> `id UUID PRIMARY KEY`. A RLS deve usar uma função personalizada ou service_role.

### Bloco D — Câmera e pré-processamento

Ver detalhes no PROGRESSO anterior (sessão 2).

### Bloco E/F — Pipeline de IA

Ver detalhes no PROGRESSO anterior (sessão 2).

### Bloco G — Telas completas

Ver detalhes no PROGRESSO anterior (sessão 2).

---

## 🔥 Próxima ação imediata

```bash
# 1. Preencher .env.local com as chaves do Firebase
cp v2/.env.local.example v2/.env.local
# Editar v2/.env.local com as chaves do Firebase Console

# 2. Subir o servidor
cd v2 && pnpm dev

# 3. Testar o fluxo completo
# → http://localhost:3000         (landing)
# → http://localhost:3000/auth/login  (login com email/senha do Flutter)
# → http://localhost:3000/scanner     (deve abrir após login)
```

**Atenção SQL do Supabase:** antes de rodar o migration SQL, alterar a FK de `profiles`:
```sql
-- Remover esta linha do SQL:
-- id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
-- Trocar por:
id UUID PRIMARY KEY,
```
Pois o Supabase Auth não está sendo usado — os UUIDs dos perfis são os UIDs do Firebase.

---

## ⚠️ Pontos de atenção e dívidas técnicas

1. **`supabase gen types`** — os tipos manuais em `types.ts` são suficientes para dev mas não têm
   a garantia de estar em sincronia com o schema real. Após criar o projeto Supabase e rodar o SQL,
   executar `npx supabase gen types typescript --project-id <ID> > src/lib/supabase/types.ts`.

2. **Supabase RLS sem Supabase Auth** — as políticas `USING (auth.uid() = user_id)` não vão funcionar
   porque não há usuário Supabase Auth. Opções:
   a) Usar `SUPABASE_SERVICE_ROLE_KEY` (sem RLS, acesso total do servidor) — mais simples para MVP.
   b) Configurar um JWT customizado no Supabase que aceite tokens Firebase.
   Para MVP: remover as policies de RLS e usar service_role key em todas as API routes.

3. **`firebase-admin` não funciona em Edge Runtime** — o middleware usa `runtime = 'nodejs'`.
   Isso significa ~50ms de cold start extra vs Edge, mas é necessário para `verifySessionCookie()`.

4. **Paleta de referência** — valores Lab são estimativas. Calibrar com colorímetro em produção.

5. **Accordion animations** — adicionados ao globals.css mas não testados visualmente.

---

## Log de sessões

| Data | Executor | Resumo |
|---|---|---|
| 2026-05-11 | Claude (sessão 1) | Scaffold completo, domínio colorimetria, design system, landing. |
| 2026-05-11 | Claude (sessão 1 addendum) | Crédito Jotta Lean Cabelos. |
| 2026-05-11 | Claude (sessão 2) | 22 componentes shadcn/ui, fontes next/font, Supabase DB, middleware Supabase, auth screens, shell protegido, AppNav, scanner/history/profile estruturais. |
| 2026-05-11 | Claude (sessão 3) | pnpm instalado; Firebase Auth implementado (projeto arte-de-colorir-cabelos); middleware migrado para Firebase session cookie (runtime nodejs); login/register/logout usando Firebase; useAuth hook; zero erros TypeScript; 24/24 testes. |

---

## Nota sobre identidade do produto

O **Hair Color Pro** é o produto. O **Jotta Lean Cabelos** é o salão onde a necessidade nasceu.
Por D-011: crédito mantido no footer, metadata SEO e README. Não remover sem autorização do criador.
