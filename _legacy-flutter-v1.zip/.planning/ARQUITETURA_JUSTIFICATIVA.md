# Justificativa Arquitetural — Hair Color Pro v2

> Este documento responde **"por quê?"** para cada escolha do `PLAN.md`. Se você é o desenvolvedor terceirizado e quer entender o raciocínio antes de executar, leia daqui. Se quer apenas executar, vá direto ao `PLAN.md`.

## 0. Contexto da decisão (histórico curto)

A primeira versão deste plano previa **React Native + NativeWind**. Foi revisitada com base em três sinais do produto:

1. **Requisito visual explícito**: shadcn/ui + glassmorphism + efeitos do reactbits.dev. Os três são primitivamente web (Radix, `backdrop-filter`, Canvas/WebGL).
2. **Offline não é requisito**: o app exige login e a IA depende de inferência remota. Isso elimina o principal argumento histórico a favor de RN puro (acesso simples a storage local e funcionamento "no avião").
3. **Distribuição em loja precisa ser preservada**: Capacitor 6 atende plenamente (é a stack de produtos como Discord Web, BBC News e diversos apps de varejo grandes).

**Resultado da revisita:** Next.js 15 + Capacitor 6 entrega a estética premium *sem reinvenção* e mantém o app como "app de loja" real. Os trade-offs são detalhados a seguir.

---

## 1. O pivô crítico: de React Native para Next.js + Capacitor

### 1.1 O que o plano anterior assumia
A versão original deste documento defendia **React Native (Expo) + NativeWind** como caminho para "ter shadcn no mobile". Essa premissa **está errada** e foi revertida.

### 1.2 Por que estava errada
- **shadcn/ui** não é uma biblioteca portável. É um conjunto de componentes **gerados como arquivos** que dependem de:
  - **Radix UI** (primitivos baseados em DOM/ARIA).
  - **Tailwind CSS** em variantes que pressupõem CSS web (`hover:`, `peer-`, `data-state`, `[&_svg]`, etc.).
  - **Framer Motion** versão web.

  Em React Native, nada disso existe nativamente — Radix não roda, várias variantes Tailwind do NativeWind não cobrem os seletores avançados, e Framer Motion mobile (`moti`) tem API diferente. Resultado: **reimplementação total**, não "uso de shadcn".

- **reactbits.dev** é ainda mais agressivamente web. Boa parte dos efeitos depende de:
  - `<canvas>` / WebGL (Aurora, Beams, Splash Cursor).
  - SVG com filtros (`feGaussianBlur`, `feTurbulence`).
  - CSS `backdrop-filter`, `mix-blend-mode`, `mask-image`.
  - `IntersectionObserver`, `getBoundingClientRect`.

  Nenhum desses primitivos existe em React Native. Portar significaria reescrever em `react-native-skia` + `reanimated` — semanas de trabalho, fidelidade visual incerta.

- **Glassmorphism** em RN passa por `expo-blur`/`@react-native-community/blur`. Funciona, mas com **limitações conhecidas**:
  - Performance ruim em Android antigo.
  - Composição com gradientes animados frequentemente trava.
  - Não há equivalente direto de `backdrop-filter: saturate()`.

### 1.3 Por que Next.js + Capacitor resolve
- **shadcn/ui** funciona **literalmente do exemplo do site** — `npx shadcn add button` e está pronto.
- **reactbits.dev** é copy-paste direto. Cada efeito é um `.tsx` que cola em `components/bits/` e roda.
- **Glass** é uma classe CSS de duas linhas (`backdrop-filter: blur() saturate()`).
- **Distribuição em loja** continua viável: **Capacitor 6** empacota o build estático do Next.js dentro de projetos iOS/Android nativos. App Store e Play Store aceitam apps Capacitor sem restrição (Discord, Burger King, BBC News usam híbrido).
- **PWA instalável** sai grátis — usuário pode instalar pelo navegador antes da app store estar pronta.
- **Câmera nativa**: `@capacitor/camera` abstrai. No web, fallback `getUserMedia` (que hoje é robusto até no Safari iOS 14+).

### 1.4 Trade-off honesto
Web-em-shell tem ~5-10% menos "fluidez" subjetiva que RN puro em cenas com listas longas e animações complexas. **No nosso caso, isso é irrelevante**: o app tem fluxo curto (5 telas), poucas listas, e a "fluidez" é dominada pelo polish visual (que é justamente onde ganhamos com shadcn + reactbits).

### 1.5 Quando essa decisão deveria ser revisitada
Reabrir essa discussão **apenas se** uma das duas coisas acontecer:
1. Performance medida (60fps) cair abaixo de 50fps em iPhone SE 2020 nas telas críticas. → otimizar antes de pivotar.
2. Necessidade futura de funcionalidade nativa sem plugin Capacitor (ex: AR/ARKit avançado). → avaliar plugin custom ou pivô seletivo.

---

## 2. Identidade Visual: glass + shadcn + reactbits

### 2.1 Por que glassmorphism e não Material/iOS nativo
- **Diferenciação**: o segmento de apps de salão é dominado por UIs "Material padrão". Glass + dark theme + acentos vibrantes cria identidade memorável.
- **Comunica precisão técnica**: profundidade em camadas faz o app parecer "instrumento", não "calculadora".
- **Estética que viraliza**: prints de apps glass ainda funcionam bem em redes sociais (Pinterest, dribbble, Instagram). Marketing orgânico de graça.

### 2.2 Por que shadcn/ui (e não Chakra, MUI, Mantine)
- **Você é dono do código**: shadcn não é uma dependência runtime, é uma **geração de arquivos**. Editamos cada componente livremente — fundamental para forçar a estética glass em todas as variants.
- **Composição com Tailwind**: design tokens vivem em CSS variables, fácil de retematizar.
- **Acessibilidade séria por padrão** (via Radix).
- **Comunidade ativa**: padrão de facto em 2024-2025.

Chakra/MUI/Mantine vêm com estética opinada que brigaria com o glass — gastaríamos mais tempo "destransformando" do que ganhando.

### 2.3 Por que reactbits.dev (e não Aceternity/Magic UI/Hyperui)
- **Catálogo de efeitos** é o mais amplo entre os "copy-paste libs" atuais.
- **Foco em animação e ambient effects** — exatamente o que o glass precisa para não parecer estático.
- **Sem lock-in**: cada efeito vira um arquivo nosso, podemos misturar com componentes de outras libs (Aceternity, etc.) à vontade.

### 2.4 Acessibilidade — não negociável
Todo efeito decorativo deve:
- Respeitar `prefers-reduced-motion: reduce`.
- Não ser o único veículo de informação (Aurora atrás de texto, mas texto tem contraste AA por conta própria).
- Permitir desligar via flag (`NEXT_PUBLIC_ENABLE_BITS=false`) para dispositivos baixo-fim.

---

## 3. IA — Visão Computacional Capilar

### 3.1 Por que modelo especializado e não GPT-4o Vision / Gemini Vision
- **Custo**: GPT-4o Vision ≈ US$ 0.01 por imagem. Modelo especializado em Replicate ≈ US$ 0.001. **10× mais barato** em escala.
- **Latência**: modelos LLM multimodais têm 3-8s p95. Um EfficientNet fine-tuned roda em 200-800ms.
- **Determinismo**: LLMs alucinam em tarefas técnicas. Um classificador puro sempre retorna probabilidades por classe — auditável, regularizável, treinável com correções dos usuários.
- **Privacidade**: foto de cabelo + rosto é PII. Manter no nosso provedor (HF Endpoints ou Replicate privado) é mais defensável que mandar para OpenAI.

### 3.2 Por que **camadas com fallback heurístico**
- **Resiliente a cold start**: se Replicate demora >4s, o app cai na heurística e mostra resultado parcial com aviso. Usuário nunca espera mais que 4s sem feedback útil. **Este é o ganho principal** — não "offline real".
- **Custo zero em modo demo**: instalação inicial sem `REPLICATE_API_TOKEN` funciona, com aviso. Útil para devs validando localmente sem queimar créditos.
- **Defesa contra rede instável**: cabeleireiros usam o app em salões, frequentemente com Wi-Fi compartilhado ruim. A heurística mantém o fluxo andando enquanto o backend é tentado em background.

> **Nota sobre offline real**: este produto **não é offline-first**. Login (Supabase Auth) e a IA principal exigem internet. A heurística é uma camada de UX para "degradação graciosa", não uma promessa de uso desconectado.

### 3.3 Por que **revisão humana obrigatória**
- Cabeleireiros profissionais não confiam (e nem deveriam) em "caixa-preta". Mostrar o resultado e permitir ajuste:
  - Aumenta confiança no produto.
  - Gera dataset gratuito de correções → alimenta re-treino mensal.
  - Reduz risco de fórmula errada gerar dano (queda capilar) — disclaimer + revisão = mitigação legal.

### 3.4 Por que calibração de cor é crítica
Cabelo sob luz amarela parece dois tons mais quente. Um modelo treinado em luz neutra erra feio em selfies de casa à noite. Mitigações:
- Onboarding educa: luz natural, perto da janela.
- Detecção de "warm cast" no client (média do canal B do RGB) bloqueia submissão severa com toast.
- **Versão futura**: cartão de calibração impresso/digital (gray card) que o usuário inclui na foto. Não no MVP, mas previsto.

---

## 4. Serviço de Colorimetria

### 4.1 Por que reescrita total (não tradução literal)
O `coloracao_helper.dart` original:
- Retorna **string concatenada** — impossível i18n, impossível UI rica.
- Lógica `if/else` esparsa — impossível testar combinatorial.
- Sem volumagem, sem proporções, sem tempo de pausa — **dados que o cabeleireiro precisa**.

A nova versão entrega **estrutura tipada + tabelas de regras**, separando dado de código. Stylist pode ajustar uma tabela JSON sem mexer em TS.

### 4.2 Por que TypeScript estrito
- Inputs vêm de fontes heterogêneas (IA, sliders, env). Tipagem com Zod no boundary previne 80% dos bugs de runtime.
- IDE autocompleta a estrutura `Formula` — dev externo não precisa adivinhar campos.

### 4.3 Por que testes com 12+ casos
Combinatorial mínimo:
- 3 ações (clarear / escurecer / manter) × 4 faixas de brancos (0/30/60/100) = 12 casos.
- Mais 4 casos de borda (input inválido, descoloração necessária >3 níveis, etc.).
- Resultado: regressões em colorimetria são pegadas no CI antes de irem para produção. Crítico porque um bug aqui pode causar **dano real** (cabelo queimado).

---

## 5. Backend — por que Supabase (e não continuar no Firebase legado)

### 5.1 Alternativas consideradas
- **Firebase** (stack original do Flutter): bom para auth, mas Firestore não-relacional dificulta queries de histórico/correções para re-treino da IA. Como temos correções estruturadas para coletar, SQL é vantagem objetiva.
- **AWS Cognito + RDS + S3**: poderoso, custo de ops alto, overkill para MVP.
- **PlanetScale + Clerk + R2**: bom, mas três fornecedores para manter.

### 5.2 Sobre a migração do Firebase legado
A base de usuários atual em Firebase Auth é pequena (app ainda não escalou). A decisão é **não migrar dados** e pedir recadastro — economiza semanas de integração de migração de senhas hash (Firebase usa scrypt customizado, Supabase usa bcrypt; portar exige a Edge Function `verifyPasswordHash` e duplicação temporária). Se a base crescer antes desta refatoração, reabrir esta decisão.

### 5.2 Por que Supabase vence
- **Tudo num lugar**: Auth + Postgres + Storage + Edge Functions.
- **RLS (Row-Level Security)** em SQL: regra de negócio "user só vê seus dados" vira **constraint do banco**, não código aplicação. Mais seguro.
- **SDK TS first-class**: integra natural com Next.js (`@supabase/ssr`).
- **Free tier generoso** para MVP B2C.
- **Postgres = futuro-prova**: se precisarmos rodar SQL analítico em correções da IA, é trivial.

---

## 6. Performance e PWA

### 6.1 Por que App Router (RSC) e não Pages Router
- Server Components reduzem JS no client → bundle inicial menor → instala como PWA mais rápido.
- Layouts aninhados batem com nossa estrutura `(marketing)` vs `(app)`.

### 6.2 Por que `output: 'export'` para Capacitor
Capacitor empacota arquivos estáticos. SSR não funciona dentro do shell nativo. Fazemos export estático e movemos toda lógica server para Route Handlers (`/api/*`) que rodam num backend hospedado (Vercel) — o shell mobile chama essas APIs por HTTPS.

---

## 7. Riscos arquiteturais conhecidos

| Risco | Decisão de mitigação |
|---|---|
| Apple rejeitar Capacitor app por "wrapped website" | Adicionar funcionalidade nativa real (camera + haptics + share) — Capacitor cumpre o critério da Apple desde 2022. Não cair na armadilha de só servir HTML. |
| Bundle inflar com framer-motion + reactbits | Code-splitting por tela; `dynamic(() => import('bits/Aurora'), { ssr: false })`. |
| Custo Replicate fora de controle | Cache de inferência por hash SHA256 da imagem; rate-limit por user; alerta de gasto diário no Replicate dashboard. |
| Bug em colorimetria gerar dano físico ao usuário | Disclaimer legal explícito + sempre exigir revisão humana antes da fórmula final. |

---

## 8. Resumo do impacto

Saímos de um app **Flutter de calculadora estática com Material genérico** para um **assistente premium híbrido (web + nativo)** que:

1. **Visualmente é referência** — glass + shadcn + reactbits, no nível dos melhores apps de 2025.
2. **Tecnicamente é robusto** — TS estrito, testes, RLS, fallback offline, schemas Zod nos boundaries.
3. **Funcionalmente resolve o problema central** — diagnóstico automático de tom e brancos via IA, com revisão humana.
4. **Distribuível em qualquer canal** — web (PWA), App Store, Play Store (via Capacitor).
5. **Preparado para evoluir** — dataset de correções alimenta re-treino mensal; regras de colorimetria em tabelas editáveis sem mexer em código.
